<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Careers</title>
 
    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/career.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
	<?php
		//Header
		include("header.php");

		/* Breadcrumb Section Begin */
		echo "<section class='breadcrumb-section set-bg' data-setbg='img/about-us1.jpg'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12 text-center'>";
		echo "				<div class='breadcrumb__text'>";
		echo "					<br><br><br><br><h2 style='color:white; font-size:80px'>Careers</h2><br>";
		echo "					<h5 style='color: white'>Here are the job vacancies available!</h5><br><br><br><br><br>";
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</section>";
		/* Breadcrumb Section End */

		/* Career Section Begin */
		echo "<section class='career spad'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-6'>";
		echo "				<div class='career__widget'>";
		echo "					<h3>WE'RE HIRING!</h3>";
		echo "					<br />";
		echo "					<p>Interested in joining us? Don't worry, we always have an open vacancy that will suit you. We currently need:</p>";
		echo "					<ul>";
		echo "						<li>Digital Marketing Strategist</li>";
		echo "						<li>Social Media Manager</li>";
		echo "						<li>Customer Service Specialist</li>";
		echo "					</ul>";
		echo "					<br />";
		echo "					<p>Perks you get while working with us:</p>";
		echo "					<ul>";
		echo "						<li>Healthcare insurance</li>";
		echo "						<li>Performance Bonus</li>";
		echo "						<li>Employee discounts</li>";
		echo "					</ul>";
		echo "					<br />";
		
		if(isset($_POST['submitted']))
		{
			//Retrieve form data
			$email = $_POST['email'];
			
			$errorMessage = "";
			$problem = false;
			
			if (empty($email)) //Validate if Email field is blank
			{
				$errorMessage = "Email cannot be empty!";
				$problem = true;
			}
			else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) //Validate if Email is valid
			{
				$errorMessage = "Invalid Email entered!";
				$problem = true;
			}
			
			
			if ($problem)
			{
				echo "					<p style='color: red'><b>Error:</b> $errorMessage</p><br />";
			}
			else
			{
				echo "					<p><b>Thank you for contacting us! We'll contact you soon.</b></p><br />";
			}
		}
		else
		{
			echo "					<p>For more information, please do not hesitate to contact us at <a href='mailto:career@team18express.com'>career@team18express.com</a> or let us contact you:</p>";
			echo "					<br>";
		}
		
		echo "					<div class='career__search'>";
		echo "						<div class='career__search__form'>";
		echo "							<form action='./career.php' method='post'>";
		echo "								<input type='text' placeholder='Enter your e-mail' name='email'>";
		echo "								<input type='hidden' name='submitted' value='true' />";
		echo "								<button type='submit' class='site-btn'>CONTACT ME</button>";
		echo "							</form>";
		echo "						</div>";
		echo "					</div>";
		echo "				</div>";
		echo "			</div>";
		echo "			<div class='col-lg-6'>";
		echo "				<div class='career__img'>";
		echo "					<img src='img/hiring.png' alt=''></img>";
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</section>";
		/* Career Section End */
		
		//Footer
		include("footer.php");
	?>

		<!-- Js Plugins -->
		<script src="js/jquery-3.3.1.min.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="js/jquery.nice-select.min.js"></script>
		<script src="js/jquery-ui.min.js"></script>
		<script src="js/jquery.slicknav.js"></script>
		<script src="js/mixitup.min.js"></script>
		<script src="js/owl.carousel.min.js"></script>
		<script src="js/main.js"></script>


</body>

</html>