<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Add Bus</title>   

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/admin.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
	<?php
		//Header
		include("header.php");
		
		/* Breadcrumb Section Begin */
		echo "<section class='breadcrumb-section set-bg' data-setbg='img/header.jpg'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12 text-center'>";
		echo "				<div class='breadcrumb__text'>";
		echo "					<h2>Add Bus</h2>";
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</section>";
		/* Breadcrumb Section End */
		
		if(isset($_POST['submitted'])){
			$valid=true;
			
			$bus_name=$_POST['bus_name'];
			$bus_num=$_POST['bus_num'];
			$bus_seat=$_POST['bus_seat'];
			$bus_type=$_POST['bus_type'];
			$company_name=$_POST['company_name'];
			
			$bus_name_error="";
			$bus_num_error="";
			$bus_seat_error="";
			$bus_type_error="";
			$company_name_error="";
				
			if(empty($bus_name)){
				$bus_name_error="The bus name field should not be empty";
				$valid=false;
			}
			else if(is_numeric($bus_name)){
				$bus_name_error="The bus name should not be numbers";
				$valid=false;
			}
			
			if(empty($bus_num)){
				$bus_num_error="The bus number field should not be empty";
				$valid=false;
			}
			
			if(empty($bus_seat)){
				$bus_seat_error="The number of seat field should not be empty";
				$valid=false;
			}
			else{ 
				if(!is_numeric($bus_seat)){
					$bus_seat_error="The bus seat should contain numbers only";
					$valid=false;
				}
				else if($bus_seat<1){
					$bus_seat_error="The bus seat should be larger than 0";
					$valid=false;
				}
			}
						
			if(empty($bus_type)){
				$bus_type_error="The bus type field should not be empty";
				$valid=false;
			}
			
			if(empty($company_name)){
				$company_name_error="The company name field should not be empty";
				$valid=false;
			}
			else if(is_numeric($company_name)){
				$company_name_error="The company name should not be numbers";
				$valid=false;
			}
				
			if($valid==true){
				$dbc = mysqli_connect('localhost','root','');

				if(mysqli_select_db($dbc,'team18_express')){
					
					$query="INSERT INTO bus (bus_name,bus_num,bus_seat,bus_type,company_name)
							VALUES('$bus_name','$bus_num','$bus_seat','$bus_type','$company_name')";
						
					if(@mysqli_query($dbc,$query)){
						print"success";
						mysqli_close($dbc);
						header("Location:admincontrolpanel.php"); 
						exit();
					}
					else{												
						echo "<div class='admin spad'>";
						echo "	<div class='container'>";
						echo "		<div class='row'>";
						echo "			<div class='col-lg-12'>";
						echo "				<center><p>Query failed.</p></center>";
						echo "			</div>";
						echo "		</div>";
						echo "	</div>";
						echo "</div>";
						
						mysqli_close($dbc);
					}
				}
			}
			else{
				echo "<div class='admin spad'>";
				echo "	<div class='container'>";
				echo "		<div class='row'>";
				echo "			<div class='col-lg-12'>";
				echo "				<div class='admin__form'>";
				echo "					<h3>Add New Bus</h3>";
				echo "					<form method='post' action='addbus.php'>";
				echo "						<div class='admin__input'>";
				echo "							<br><p>Bus name:</p>";
				echo "							<input name='bus_name' type='text' size='30' placeholder='Enter bus name'/>";
				echo "							<br><font color='red'>*$bus_name_error</font>";
				echo "						</div>";
				echo "						<div class='admin__input'>";
				echo "							<br><p>Bus number:</p>";
				echo "							<input name='bus_num' type='text' size='30' placeholder='Enter bus number'/>";
				echo "							<br><font color='red'>*$bus_num_error</font>";
				echo "						</div>";
				echo "						<div class='admin__input'>";
				echo "							<br><p>Number of seat:</p>";
				echo "							<input name='bus_seat' type='number' size='5' placeholder='Enter number of seat'/>";
				echo "							<br><font color='red'>*$bus_seat_error</font>";
				echo "						</div>";
				echo "						<div class='admin__input'>";
				echo "							<br><p>Bus type:</p>";
				echo "							<select name='bus_type'>";
				echo "								<option value=''>Choose bus type</option>";
				echo "								<option value='Normal'>Normal</option>";
				echo "								<option value='Luxury'>Luxury</option>";
				echo "							</select>";
				echo "							<p><font color='red'>*$bus_type_error</p>";
				echo "						</div>";
				echo "						<br /><br />";
				echo "						<div class='admin__input'>";
				echo "							<p>Company name:</p>";
				echo "							<input name='company_name' type='text' size='30' placeholder='Enter company name' />";
				echo "							<br><font color='red'>*$company_name_error</font>";
				echo "						</div><br><br>";
				echo "						<a href='admincontrolpanel.php'><button class='admin-btn' type='button'>Back</button></a>";
				echo "						<button class='admin-btn' type='submit'>Submit</button><input type='hidden' name='submitted' value='true'/>";
				echo "					</form>";
				echo "				</div>";
				echo "			</div>";
				echo "		</div>";
				echo "	</div>";
				echo "</div>";
			}
		}
	
		else{
			addForm();
		}
		
		//Footer
		include("footer.php");
	?>
    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

</body>
</html>

<?php
	function addForm(){

		echo "<div class='admin spad'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12'>";
		echo "				<div class='admin__form'>";
		echo "					<h4>Add New Bus</h4>";
		echo "					<form method='post' action='addbus.php'>";
		echo "						<div class='admin__input'>";
		echo "							<br><p>Bus name:</p>";
		echo "							<input name='bus_name' type='text' size='30' placeholder='Enter bus name'/>";
		echo "						</div>";
		echo "						<div class='admin__input'>";
		echo "							<br><p>Bus number:</p>";
		echo "							<input name='bus_num' type='text' size='30' placeholder='Enter bus number'/>";
		echo "						</div>";
		echo "						<div class='admin__input'>";
		echo "							<br><p>Number of seat:</p>";
		echo "							<input name='bus_seat' type='number' size='5' placeholder='Enter number of seat'/>";
		echo "						</div>";
		echo "						<div class='admin__input'>";
		echo "							<br><p>Bus type:</p>";
		echo "							<select name='bus_type'>";
		echo "								<option value=''>Choose bus type</option>";
		echo "								<option value='Normal'>Normal</option>";
		echo "								<option value='Luxury'>Luxury</option>";
		echo "							</select>";
		echo "						</div>";
		echo "						<br /><br /><br />";
		echo "						<div class='admin__input'>";
		echo "							<br><p>Company name:</p>";
		echo "							<input name='company_name' type='text' size='30' placeholder='Enter company name' />";
		echo "						</div><br><br>";
		echo "						<a href='admincontrolpanel.php'><button class='admin-btn' type='button'>Back</button></a>";
		echo "						<button class='admin-btn' type='submit'>Submit</button><input type='hidden' name='submitted' value='true'/>";
		echo "					</form>";
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</div>";		
		
	}
	
	
	
		
		
?>