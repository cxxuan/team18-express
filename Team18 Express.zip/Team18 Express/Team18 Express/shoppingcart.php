<?php
session_start();
if(!empty($_GET["action"])) {
	switch($_GET["action"]) {
		case "add":
			if(empty($_SESSION["shopping_cart"])) {
				$_SESSION["shopping_cart"] = $_SESSION['cart'];
				$status = "<div class='box'>Product is added to your cart!</div>";
			}
			else{
				$array_keys = array_keys($_SESSION["shopping_cart"]);
				if(in_array($_GET['booking_num'],$array_keys)) {
					
				}
				else{
				$itemArray = $_SESSION['cart'];

				$_SESSION["shopping_cart"] = array_merge($_SESSION["shopping_cart"],$itemArray);
				}
			}
			break;
		case "remove":
			if(!empty($_SESSION["shopping_cart"])) {
				foreach($_SESSION["shopping_cart"] as $k => $v) {
						if($_GET["booking_num"] == $k)
							unset($_SESSION["shopping_cart"][$k]);				
						if(empty($_SESSION["shopping_cart"]))
							unset($_SESSION["shopping_cart"]);
				}
			}
			break;
		case "empty":
			unset($_SESSION["shopping_cart"]);
			break;	
	}
}
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Control Panel</title>    

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/cart.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
		<?php
		include("header.php");
					
		/* Breadcrumb Section Begin */
		echo "<section class='breadcrumb-section set-bg' data-setbg='img/header.jpg'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12 text-center'>";
		echo "				<div class='breadcrumb__text'>";
		echo "					<h2>Shopping Cart</h2>";
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</section>";
		/* Breadcrumb Section End */
		
		echo "<div class='cart spad'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12'>";
		
		if(isset($_POST['submitted'])){
			$dbc = mysqli_connect('localhost','root','');
			@mysqli_select_db($dbc,'team18_express');
			$result=mysqli_query($dbc,"SELECT user_id,username FROM user");
			while($row=mysqli_fetch_array($result)){
				if($_SESSION['id']==$row['username']){
					$user_id=$row['user_id'];
				}
			}
			date_default_timezone_set('Asia/Kuala_Lumpur');
			$booking_date=date("Y/m/d",time());
			
			foreach ($_SESSION["shopping_cart"] as $item){
				$total_price += (50*$item["ticket_quantity"]);
				$result="INSERT INTO booking (booking_num,booking_date,ticket_quantity,booking_price,departure_date,booking_status,user_id,route_id)
						 VALUES('".$item["booking_num"]."','$booking_date','".$item["ticket_quantity"]."','$total_price','".$item["departure_date"]."','Booked','$user_id','".$item["route_id"]."')";
				if(mysqli_query($dbc,$result)){
					print"scucess";
				}
				else{
					print"fail";
				}
			}
			$_SESSION['shopping_cart']=array();
			$_SESSION['cart']=array();
			header('Location: home.php'); //Redirect user to Home page
			exit();
		}
		else{
		?>
		<a style="color: blue;" href="shoppingcart.php?action=empty">Empty Cart</a><br /><br />
		<?php
		if(isset($_SESSION["shopping_cart"])){
			$total_quantity = 0;
			$total_price = 0;
		?>
		<table class="table table-bordered">
			<tr>
				<th style="text-align:left;">Booking reference number</th>
				<th style="text-align:left;">Bus name</th>
				<th style="text-align:left;">Departure date</th>
				
				<th style="text-align:left;">Route name</th>
				<th style="text-align:left;">Departure</th>
				<th style="text-align:left;">Destination</th>
				
				<th style="text-align:right;" width="5%">Quantity</th>
				<th style="text-align:right;" width="10%">Price</th>
				<th style="text-align:right;" width="10%">Total price</th>
				<th style="text-align:center;" width="5%">Remove</th>
			</tr>	
			<?php
				$i=0;
				foreach ($_SESSION["shopping_cart"] as $item){
					$item_price = $item["ticket_quantity"]*50;
					?>
							<tr>
								<td><?php echo $item["booking_num"]; ?></td>
								<td><?php echo $item["bus_name"]; ?></td>
								<td><?php echo $item["departure_date"]; ?></td>
								<td><?php echo $item["route_name"]; ?></td>
								<td><?php echo $item["departure"]; ?></td>
								<td><?php echo $item["destination"]; ?></td>
								<td><?php echo $item["ticket_quantity"]; ?></td>
								<td style="text-align:right;">RM 50</td>
								<td style="text-align:right;"><?php echo "RM ". number_format($item_price,2); ?></td>
								<td style="text-align:center;"><a style="color: blue;" href="shoppingcart.php?action=remove&booking_num=<?php echo $item["booking_num"]; ?>">Remove Item</a></td>
							</tr>
							<?php
							$total_price += (50*$item["ticket_quantity"]);
					}
					?>

			<tr>
				<td colspan="7" align="right">Total:</td>
				<td align="right" colspan="2"><strong><?php echo "RM ".number_format($total_price, 2); ?></strong></td>
				<td><form method="post" action="shoppingcart.php"><input type='submit' value='Purchase'/><input type='hidden' name='submitted' value='true' /></form></td>
			</tr>
		</table>		
		  <?php
		} else {
		?>
		<p>Your Cart is Empty</p>
		<?php 
		}
		}
		?>
		<a style="color: blue;" href="booking.php">BACK</a>
		
		<?php
			echo "			</div>";
			echo "		</div>";
			echo "	</div>";
			echo "</div>";
			
			include("footer.php");
		?>
		
    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

</body>
</html>