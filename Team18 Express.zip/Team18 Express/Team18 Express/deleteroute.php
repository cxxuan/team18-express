<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Delete Route</title>    

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/admin.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
		<?php
		if(isset($_POST['submitted'])){
			$route_id=$_POST['route_id'];
			
			$dbc = mysqli_connect('localhost','root','');
			@mysqli_select_db($dbc,'team18_express');
			if($dbc){
				$result="DELETE FROM route WHERE route.route_id = $route_id";
				
					if(@mysqli_query($dbc,$result)){
						print"success";
						mysqli_close($dbc);
						header("Location:admincontrolpanel.php"); 
						exit();
					}
			}
			else{
				print"query failed";
				mysqli_close($dbc);
			}
		}
		
		else{
			$id=$_GET['id'];
			
			$dbc = mysqli_connect('localhost','root','');
			@mysqli_select_db($dbc,'team18_express');
			if($dbc){
				$result=mysqli_query($dbc,"SELECT route_name,departure,destination,weekday,departure_time,duration 
				FROM route WHERE route.route_id = $id");
					
					$row=mysqli_fetch_row($result);
					
					include("header.php");
					
					/* Breadcrumb Section Begin */
					echo "<section class='breadcrumb-section set-bg' data-setbg='img/header.jpg'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12 text-center'>";
					echo "				<div class='breadcrumb__text'>";
					echo "					<h2>Delete Route</h2>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</section>";
					/* Breadcrumb Section End */
					
					echo "<div class='admin spad'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12'>";
					echo "				<div class='admin__form'>";
					echo "					<h4>Confirm to delete route?</h4>";
					echo "					<table width='80%' class='table table-bordered'>";
					echo "						<tr>";
					echo "							<th>Route name</th>";
					echo "							<td>".$row[0]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Departure</th>";
					echo "							<td>".$row[1]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Destination</th>";
					echo "							<td>".$row[2]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Weekday</th>";
					echo "							<td>".$row[3]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Departure time</th>";
					echo "							<td>".$row[4]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Travel duration</th>";
					echo "							<td>".$row[5]."</td>";
					echo "						</tr>";
					echo "					</table>";
					echo "					<form method='post' action='deleteroute.php'>";
					echo "						<a href='admincontrolpanel.php'><button class='admin-btn' type='button'>Back</button></a>";
					echo "						<button class='admin-btn' type='submit'>Delete</button>";
					echo "						<input type='hidden' name='submitted' value='true'/>";
					echo "						<input type='hidden' name='route_id' value='$id'/>";
					echo "					</form>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</div>";
					
					include("footer.php");
				}
				else{
					include("header.php");
					
					/* Breadcrumb Section Begin */
					echo "<section class='breadcrumb-section set-bg' data-setbg='img/header.jpg'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12 text-center'>";
					echo "				<div class='breadcrumb__text'>";
					echo "					<h2>Delete Bus</h2>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</section>";
					/* Breadcrumb Section End */
					
					echo "<div class='admin spad'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12'>";
					echo "				<center><p>Failed to fetch data.</p></center>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</div>";
					
					include("footer.php");
				}
			mysqli_close($dbc);
		}
		?>	
    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

</body>
</html>