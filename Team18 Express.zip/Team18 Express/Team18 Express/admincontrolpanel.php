<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Admin Control Panel</title>    

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/admin.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
	<?php
		include("header.php");
					
		/* Breadcrumb Section Begin */
		echo "<section class='breadcrumb-section set-bg' data-setbg='img/header.jpg'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12 text-center'>";
		echo "				<div class='breadcrumb__text'>";
		echo "					<h2>Admin Control Panel</h2>";
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</section>";
		/* Breadcrumb Section End */
		
		if(isset($_POST['submitted'])){
			showBusResult();
			displayRouteList();
		}
		
		else if(isset($_POST['submittedroute'])){
			displayBusList();
			showRouteResult();
		}
		
		else{
			displayBusList();
			//=================================================================
			displayRouteList();
		}
		
		include("footer.php");
		
	?>	
    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

</body>
</html>

<?php
	function searchBusForm(){
	echo"<form method='post' action='admincontrolpanel.php'>";
	echo"	<div class='admin__input'>";
	echo"		<div class='row'>";
	echo"			<div class='col-lg-1'>";
	echo"				<p style='margin-bottom: 0px;'>Search:</p>";
	echo"			</div>";
	echo"			<div class='col-lg-6'>";
	echo"				<input name='bus_query' type='text' size='25'/>";
	echo"			</div>";
	echo"			<div class='col-lg-5'>";
	echo"				<select name='query_type'>";
	echo"					<option value='bus_name'>Bus name</option>";
	echo"					<option value='bus_num'>Bus number</option>";
	echo"					<option value='bus_seat'>Number of seat</option>";
	echo"					<option value='bus_type'>Bus type</option>";
	echo"					<option value='company_name'>Company name</option>";
	echo"				</select>";
	echo"				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class='admin-btn' style='padding: 13px 60px 12px;' type='submit'>Search</button>";
	echo"			</div>";
	echo"		</div>";
	echo"	</div>";
	echo"	<input type='hidden' name='submitted' value='true'/>";
	echo"</form>";
	}
	
	function searchRouteForm(){
	echo"<form method='post' action='admincontrolpanel.php'>";
	echo"	<div class='admin__input'>";
	echo"		<div class='row'>";
	echo"			<div class='col-lg-1'>";
	echo"				<p style='margin-bottom: 0px;'>Search:</p>";
	echo"			</div>";
	echo"			<div class='col-lg-6'>";
	echo"				<input name='route_query' type='text' size='25'/>";
	echo"			</div>";
	echo"			<div class='col-lg-5'>";
	echo"				<select name='query_typeroute'>";
	echo"					<option value='bus_name'>Bus name</option>";
	echo"					<option value='route_name'>Route name</option>";
	echo"					<option value='departure'>Departure</option>";
	echo"					<option value='destination'>Destination</option>";
	echo"					<option value='weekday'>Weekday</option>";
	echo"					<option value='departure_time'>Departure Time</option>";
	echo"					<option value='duration'>Duration</option>";
	echo"				</select>";
	echo"				&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<button class='admin-btn' style='padding: 13px 60px 12px;' type='submit'>Search</button>";
	echo"			</div>";
	echo"		</div>";
	echo"	</div>";
	echo"	<input type='hidden' name='submittedroute' value='true'/>";
	echo"</form>";
	}
	
	function displayBusList(){
		echo "<div class='admin spad'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12'>";
		echo "				<div class='admin__form'>";
		echo "					<h4>Bus list</h4>";
		searchBusForm();
				
		$dbc = mysqli_connect('localhost','root','');
		@mysqli_select_db($dbc,'team18_express');
		if($dbc){
			$result=mysqli_query($dbc,"SELECT bus_id,bus_name,bus_num,bus_seat,bus_type,company_name FROM bus");

				echo "					<table width='100%' class='table table-bordered'>";
				echo "						<tr>";
				echo "							<th>Bus name</th>";
				echo "							<th>Bus number</th>";
				echo "							<th>Number of Seat</th>";
				echo "							<th>Bus type</th>";
				echo "							<th>Company name</th>";
				echo "							<th>Action</th>";
				echo "							<th>Action</th>";
				echo "						</tr>";
				
				$i=1;
				while($row=mysqli_fetch_array($result)){
					$i=$row['bus_id'];
					
					echo"
					<tr>
						<td>".$row['bus_name']."</td>
						<td>".$row['bus_num']."</td>
						<td>".$row['bus_seat']."</td>
						<td>".$row['bus_type']."</td>
						<td>".$row['company_name']."</td>
						<td><a href='editbus.php?id=$i'>Edit</a></td>
						<td><a href='deletebus.php?id=$i'>Delete</a></td>
					</tr>
					";
				}
				
				echo "					</table>";
		}
				
		else{
			echo"query failed";
		}
		mysqli_close($dbc);
		echo"<a href='addbus.php'><button class='admin-btn' type='button'>Add</button></a>";
		
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</div>";
	}
	
	function displayRouteList(){
		echo "<div class='admin spad'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12'>";
		echo "				<div class='admin__form'>";
		echo "					<h4>Route list</h4>";
		searchRouteForm();
		
		$dbc = mysqli_connect('localhost','root','');
		@mysqli_select_db($dbc,'team18_express');
		if($dbc){
			$result=mysqli_query($dbc,"SELECT r.route_id,r.route_name,r.departure,r.destination,
					r.weekday,r.departure_time,r.duration,b.bus_name
					FROM route r
					JOIN bus b 
					ON (r.bus_id=b.bus_id)");
					
					echo "					<table width='100%' class='table table-bordered'>";
					echo "						<tr>";
					echo "							<th>Bus name</th>";
					echo "							<th>Route name</th>";
					echo "							<th>Departure</th>";
					echo "							<th>Destination</th>";
					echo "							<th>Weekday</th>";
					echo "							<th>Departure time</th>";
					echo "							<th>Travel duration</th>";
					echo "							<th>Action</th>";
					echo "							<th>Action</th>";
					echo "						</tr>";
					
					$i=1;
					while($row=mysqli_fetch_array($result)){
						$i=$row['route_id'];
						
						echo"
						<tr>
							<td>".$row['bus_name']."</td>
							<td>".$row['route_name']."</td>
							<td>".$row['departure']."</td>
							<td>".$row['destination']."</td>
							<td>".$row['weekday']."</td>
							<td>".$row['departure_time']."</td>
							<td>".$row['duration']."</td>
							<td><a href='editroute.php?id=$i'>Edit</a></td>
							<td><a href='deleteroute.php?id=$i'>Delete</a></td>
						</tr>
						";
				}
			echo "					</table>";
		}
				
		else{
			echo"query failed";
		}
			
		mysqli_close($dbc);
		echo"<a href='addroute.php'><button class='admin-btn' type='button'>Add</button></a>";
		
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</div>";
	}
	
	function showBusResult(){
		$found=false;
		$query_type=$_POST['query_type'];
		$bus_query=$_POST['bus_query'];
		
		echo "<div class='admin spad'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12'>";
		echo "				<div class='admin__form'>";
		
		$dbc = mysqli_connect('localhost','root','');
		@mysqli_select_db($dbc,'team18_express');
		if($dbc){
			$result=mysqli_query($dbc,"SELECT bus_id,bus_name,bus_num,bus_seat,bus_type,company_name FROM bus");

				echo "					<h4>Search result</h4>";
				searchBusForm();
				
				
				echo "					<table width='100%' class='table table-bordered'>";
				echo "						<tr>";
				echo "							<th>Bus name</th>";
				echo "							<th>Bus number</th>";
				echo "							<th>Number of Seat</th>";
				echo "							<th>Bus type</th>";
				echo "							<th>Company name</th>";
				echo "							<th>Action</th>";
				echo "							<th>Action</th>";
				echo "						</tr>";
				
				$i=1;
				while($row=mysqli_fetch_array($result)){
					if($bus_query==$row[$query_type]){
						$i=$row['bus_id'];
								
						echo"
						<tr>
							<td>".$row['bus_name']."</td>
							<td>".$row['bus_num']."</td>
							<td>".$row['bus_seat']."</td>
							<td>".$row['bus_type']."</td>
							<td>".$row['company_name']."</td>
							<td><a href='editbus.php?id=$i'>Edit</a></td>
							<td><a href='deletebus.php?id=$i'>Delete</a></td>
						</tr>
						";
						$found=true;
					}
				}
			echo"</table>";
		}
				
		else{
			echo"query failed";
		}
		
		if($found==false){
			echo"Not found<br/><br/>";
		}
		
		mysqli_close($dbc);
		echo"<a href='admincontrolpanel.php'><button class='admin-btn' type='button'>Show all</button></a>&nbsp;";
		echo"<a href='addbus.php'><button class='admin-btn' type='button'>Add</button></a>";
		
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</div>";
	}
	
	function showRouteResult(){
		$found=false;
		$query_typeroute=$_POST['query_typeroute'];
		$route_query=$_POST['route_query'];
		
		echo "<div class='admin spad'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12'>";
		echo "				<div class='admin__form'>";
		
		$dbc = mysqli_connect('localhost','root','');
		@mysqli_select_db($dbc,'team18_express');
		if($dbc){
			$result=mysqli_query($dbc,"SELECT r.route_id,r.route_name,r.departure,r.destination,
							r.weekday,r.departure_time,r.duration,b.bus_name
							FROM route r
							JOIN bus b 
							ON (r.bus_id=b.bus_id)");

				echo "					<h4>Search result</h4>";
				searchRouteForm();
				
				echo "					<table width='100%' class='table table-bordered'>";
				echo "						<tr>";
				echo "							<th>Bus name</th>";
				echo "							<th>Route name</th>";
				echo "							<th>Departure</th>";
				echo "							<th>Destination</th>";
				echo "							<th>Weekday</th>";
				echo "							<th>Departure time</th>";
				echo "							<th>Travel duration</th>";
				echo "							<th>Action</th>";
				echo "							<th>Action</th>";
				echo "						</tr>";
					
				$i=1;
				while($row=mysqli_fetch_array($result)){
					if($route_query==$row[$query_typeroute]){
						$i=$row['route_id'];
								
						echo"
						<tr>
							<td>".$row['bus_name']."</td>
							<td>".$row['route_name']."</td>
							<td>".$row['departure']."</td>
							<td>".$row['destination']."</td>
							<td>".$row['weekday']."</td>
							<td>".$row['departure_time']."</td>
							<td>".$row['duration']."</td>
							<td><a href='editroute.php?id=$i'>Edit</a></td>
							<td><a href='deleteroute.php?id=$i'>Delete</a></td>
						</tr>
						";
						$found=true;
					}
				}
			echo"</table>";
		}
				
		else{
			echo"query failed";
		}
		
		if($found==false){
			echo"Not found<br/><br/>";
		}
		
		mysqli_close($dbc);
		echo"<a href='admincontrolpanel.php'><button class='admin-btn' type='button'>Show all</button></a>&nbsp;";
		echo"<a href='addbus.php'><button class='admin-btn' type='button'>Add</button></a>";
	}

?>