<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<meta name="description" content="Ogani Template">
	<meta name="keywords" content="Ogani, unica, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Available Buses</title>

	<!-- Css Styles -->
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
	<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
	<link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
	<link rel="stylesheet" href="css/nice-select.css" type="text/css">
	<link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
	<link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
	<link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/ps_style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  color: #000000;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>	
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
	<?php

	//retrieve and display the webpage header
	include ('header.php');
	
	/* Breadcrumb Section Begin */
	echo "<div class='hero__item set-bg' data-setbg='img/about-us1.jpg'>";
		echo "<div class='col-lg-12 text-center'>";
		echo "<div class='breadcrumb__text'>";
			echo "<h2 style='color:white; font-size:80px'>Available Buses</h2>";
		echo "</div>";
		echo "</div>";
	echo "</div>";
	/* Breadcrumb Section End */
	
	?>

<!-- Print out the table's header / fields first -->
<table>
		<tr>
			<th>Company Name</th>
			<th>Bus Name</th>
			<th>Bus Type</th>
			<th>Bus Num</th>
			<th>Route Name</th>
			<th>Departure</th>
			<th>Departure Time</th>
			<th>Duration</th>
		</tr>
<?php

	if($dbc = mysqli_connect('localhost', 'root', '')){//if successfully establish connection with database server
		
		if (!mysqli_select_db($dbc, 'team18_express')){//if cannot select the database
		
			//print error message
			echo "<center><p>Could not select the database because: " . mysqli_error($dbc) . ".</p></center><br />";
			
		}else{//if successfully select the database
			
			if(isset($_GET['destination'])){//if the variable is set with a destination value
			
				//define the query to get certain route information using variable destination 
				$query1 = "SELECT * FROM route WHERE (destination = '{$_GET['destination']}')";
				
				//execute the query
				if ($result1 = mysqli_query($dbc, $query1)){
					
					//retrieve the information
					$row1 = mysqli_fetch_array($result1, MYSQLI_ASSOC);
					
					//define query to get certain bus information using variable bus_id
					$query2 = "SELECT * FROM bus WHERE (bus_id= '{$row1['bus_id']}')";
					
					//execute the query
					if ($result2 = mysqli_query($dbc, $query2)){
						
						//retrieve information
						$row2 = mysqli_fetch_array($result2);
						
						//display available buses details
						echo "<tr>";
						echo "<td>{$row2['company_name']}</td>"; //company name
						echo "<td>{$row2['bus_name']}</td>"; //bus name
						echo "<td>{$row2['bus_type']}</td>"; //bus type
						echo "<td>{$row2['bus_num']}</td>"; //bus num
						
					}else {//if could not retrieve data
						
						//display error message
						echo "<center><p>Could not retrieve the details because: " . mysqli_error($dbc) . ".</p></center><br />";
						
					}
					
					//continue display some route information
					echo "<td>{$row1['route_name']}</td>";
					echo "<td>{$row1['departure']}</td>";
					echo "<td>{$row1['departure_time']}</td>";
					echo "<td>{$row1['duration']}</td>";
					echo "</tr>";
					
				}else {//if cannot retrieve data
					
					//display error message
					echo "<center><p>Could not retrieve the details because: " . mysqli_error($dbc) . ".</p></center><br />";
					
				}
					
			}else{
			
				//display error message
				echo "<center><p>This page has been accessed in error.</center><br /></p>";
				
			}
			
		}
		
		//close the connection 
		mysqli_close($dbc);
		
	}else{//if cannot connect to database server
		
		//print error message
		echo "<center><p>Could not connect to MySQL: " . mysqli_error($dbc) . ".</p></center><br />";
		
	}
?>
</table>

	<?php
	//retrieve and display the webpage footer
	include ('footer.php');
	?>
	
	<!-- Js Plugins -->
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/jquery.slicknav.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

</body>
</html>