-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 02, 2020 at 04:10 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `team18_express`
--

-- --------------------------------------------------------

--
-- Table structure for table `booking`
--

CREATE TABLE `booking` (
  `booking_num` varchar(200) NOT NULL,
  `booking_date` date NOT NULL,
  `ticket_quantity` int(10) UNSIGNED NOT NULL,
  `booking_price` double UNSIGNED NOT NULL,
  `departure_date` date NOT NULL,
  `booking_status` varchar(50) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `route_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `booking`
--

INSERT INTO `booking` (`booking_num`, `booking_date`, `ticket_quantity`, `booking_price`, `departure_date`, `booking_status`, `user_id`, `route_id`) VALUES
('JLH912', '2020-08-02', 1, 300, '2020-08-08', 'Booked', 6, 9),
('UNC573', '2020-08-02', 3, 250, '2020-08-18', 'Booked', 7, 9),
('XKK036', '2020-08-02', 1, 50, '2020-08-03', 'Booked', 7, 9),
('YZF544', '2020-08-02', 5, 250, '2020-08-26', 'Booked', 6, 10);

-- --------------------------------------------------------

--
-- Table structure for table `bus`
--

CREATE TABLE `bus` (
  `bus_id` int(10) UNSIGNED NOT NULL,
  `bus_name` varchar(200) NOT NULL,
  `bus_num` varchar(50) NOT NULL,
  `bus_seat` int(10) UNSIGNED NOT NULL,
  `bus_type` varchar(50) NOT NULL,
  `company_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bus`
--

INSERT INTO `bus` (`bus_id`, `bus_name`, `bus_num`, `bus_seat`, `bus_type`, `company_name`) VALUES
(7, 'Super Bus', 'ADD1111', 60, 'Luxury', 'Vincent Express'),
(9, 'Tangent Express', 'DDD1111', 20, 'Normal', 'Keat Tour');

-- --------------------------------------------------------

--
-- Table structure for table `route`
--

CREATE TABLE `route` (
  `route_id` int(10) UNSIGNED NOT NULL,
  `route_name` varchar(200) NOT NULL,
  `departure` varchar(200) NOT NULL,
  `destination` varchar(200) NOT NULL,
  `weekday` varchar(50) NOT NULL,
  `departure_time` varchar(200) NOT NULL,
  `duration` int(10) UNSIGNED NOT NULL,
  `bus_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `route`
--

INSERT INTO `route` (`route_id`, `route_name`, `departure`, `destination`, `weekday`, `departure_time`, `duration`, `bus_id`) VALUES
(9, 'KL station express ', 'Penang', 'Kuala Lumpur', 'Monday', '9AM', 120, 9),
(10, 'Metropolitan - KLIA', 'KLsentral', 'KLIA', 'Tuesday', '12PM', 60, 7);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(11) UNSIGNED NOT NULL,
  `username` varchar(50) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(200) NOT NULL,
  `phone_num` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `username`, `fname`, `lname`, `password`, `email`, `address`, `phone_num`) VALUES
(5, 'leehong', 'Lee', 'Hong', '12345qQ!', 'leehong@gmail.com', 'Inti, Penang', '0123456789'),
(6, 'khy123', 'Hui Ying', 'Khoo', 'Khy@12345', 'khy123@gmail.com', 'Berjaya, Penang', '0124455667'),
(7, 'vlee123', 'Vincent', 'Lee', 'Vlee123$', 'vlee@gmail.com', 'Inti, Penang', '0128877665');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booking`
--
ALTER TABLE `booking`
  ADD UNIQUE KEY `booking_num` (`booking_num`),
  ADD KEY `fk_route_id` (`route_id`),
  ADD KEY `fk_user_id` (`user_id`);

--
-- Indexes for table `bus`
--
ALTER TABLE `bus`
  ADD PRIMARY KEY (`bus_id`);

--
-- Indexes for table `route`
--
ALTER TABLE `route`
  ADD PRIMARY KEY (`route_id`),
  ADD KEY `fk_bus_id` (`bus_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bus`
--
ALTER TABLE `bus`
  MODIFY `bus_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `route`
--
ALTER TABLE `route`
  MODIFY `route_id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booking`
--
ALTER TABLE `booking`
  ADD CONSTRAINT `fk_route_id` FOREIGN KEY (`route_id`) REFERENCES `route` (`route_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `route`
--
ALTER TABLE `route`
  ADD CONSTRAINT `fk_bus_id` FOREIGN KEY (`bus_id`) REFERENCES `bus` (`bus_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
