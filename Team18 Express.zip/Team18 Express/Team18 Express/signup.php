<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Register</title>  

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/register.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
	<?php
		//Header
		include("header.php");

		/* Breadcrumb Section Begin */
		echo "<section class='breadcrumb-section set-bg' data-setbg='img/about-us3.jpg'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12 text-center'>";
		echo "				<div class='breadcrumb__text'>";
		echo "					<br><br><br><br><h2 style='color:white; font-size:80px'>Register</h2><br>";
		echo "					<h5 style='color: white'>Create your account now!</h5><br><br><br><br>";
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</section>";
		/* Breadcrumb Section End */

		//If form is submitted, do the following:
		if (isset($_POST['submitted']))
		{
			//Retrieve form data
			$fName = $_POST['fName'];
			$lName = $_POST['lName'];
			$address = $_POST['address1'].$_POST['address2'];
			$username = $_POST['username'];
			$phone = $_POST['phone'];
			$email = $_POST['email'];
			$password = $_POST['password'];
			$retypePassword = $_POST['retypePassword'];
			
			$problem = false; //Variable determining if there is any errors
			
			$fNameError = "";
			$lNameError = "";
			$addressError = "";
			$usernameError = "";
			$phoneError = "";
			$emailError = "";
			$passwordError = "";
			$retypePasswordError = "";
			
			//Validate form fields
			//Validate First Name
			if(empty($fName)) //Validate whether First Name is blank
			{
				$fNameError = "First Name cannot be empty!";
				$problem = true;
			}
			else if(!preg_match ("/^[a-zA-Z\s]+$/",$fName)) //Validate whether First Name only consist of letters
			{
				$fNameError = "First Name must only contain letters!";
				$problem = true;
			}
			
			//Validating Last Name
			if(empty($lName)) //Validate whether Last Name is blank
			{
				$lNameError = "Last Name cannot be empty!";
				$problem = true;
			}
			else if(!preg_match ("/^[a-zA-Z\s]+$/",$lName)) //Validate whether Last Name only consist of letters
			{
				$lNameError = "Last Name must only contain letters!";
				$problem = true;
			}
			
			//Validating Address - whether Address is blank
			if(empty($address))
			{
				$addressError = "Address cannot be empty!";
				$problem = true;
			}
			
			//Validating Username - whether Username is blank
			if(empty($username))
			{
				$usernameError = "Username cannot be empty!";
				$problem = true;
			}
			
			//Validating H/P Number
			if(empty($phone)) //Validate whether H/P Number is blank
			{
				$phoneError = "H/P Number cannot be empty!";
				$problem = true;
			}
			else
			{
				if(!is_numeric($phone)) //Validate whether H/P Number only contain digits
				{
					$phoneError = "H/P Number must only contain digits!";
					$problem = true;
				}
				else if(strlen($phone)<10 || strlen($phone)>11) //Validate whether H/P Number only contain the right amount of digits
				{
					$phoneError = "Invalid H/P Number entered!";
					$problem = true;
				}
			}
			
			//Validating Email
			if(empty($email)) //Validate whether Email is blank
			{
				$emailError = "Email cannot be empty!";
				$problem = true;
			}
			else if (!filter_var($email, FILTER_VALIDATE_EMAIL)) //Validate whether Email is a valid email
			{
				$emailError = "Invalid Email entered!";
				$problem = true;
			}
			
			//Validating Password
			if(empty($password)) //Validate whether Password is blank
			{
				$passwordError = "Password cannot be empty!";
				$problem = true;
			}
			else if(strlen($password) < 8){//if user entered a password shorter than 8 characters
			
				if(preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*?[#?!@$%^&*-]).*$/', $password)){//however user did comply to other safe password requirements
					
					//display error message
					$passwordError="Password cannot be shorter than 8 characters.";
					$problem = true;
					
				}else{//if user also did not comply to other safe password requirements
					
					//display error message
					$passwordError="Password cannot be shorter than 8 characters and must include at least one lowercase character, uppercase character, digit, and symbol.";
					$problem = true;
					
				}
		
			}else if(!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*?[#?!@$%^&*-]).*$/', $password)){//if user's password is acceptable in length but did not comply to certain requirements 
				
				//display error message
				$passwordError="Password must include at least one lowercase character, uppercase character, digit, and symbol.";
				$problem = true;
				
			}

			//Validate Retype Password
			if (empty($retypePassword)) //Validate whether Retype Password is blank
			{
				$retypePasswordError = "Retype Password field cannot be empty!";
				$problem = true;
			}
			else if ($retypePassword != $password) //Validate whether Retype Password is similar with Password entered
			{
				$retypePasswordError = "Passwords do not match!";
				$problem = true;
			}
			
			//If there is problem, redisplay the form with appropriate error message
			if ($problem)
			{
				echo "<section class='auth spad'>";
				echo "	<div class='container'>";
				echo "		<div class='auth__form'>";
				echo "			<h4>Registration form</h4>";
				echo "			<form action='./signup.php' method='post'>";
				echo "				<div class='row'>";
				echo "					<div class='col-lg-12'>";
				echo "						<div class='row'>";
				echo "							<div class='col-lg-6'>";
				echo "								<div class='auth__input'>";
				echo "									<p>Fist Name<span style='color:#dd2222;'>*</span></p>";
				echo "									<input type='text' name='fName'>";
				echo "									<p style='color: red;'>$fNameError</p>";
				echo "								</div>";
				echo "							</div>";
				echo "							<div class='col-lg-6'>";
				echo "								<div class='auth__input'>";
				echo "									<p>Last Name<span style='color:#dd2222;'>*</span></p>";
				echo "									<input type='text' name='lName'>";
				echo "									<p style='color: red;'>$lNameError</p>";
				echo "								</div>";
				echo "							</div>";
				echo "						</div>";
				echo "						<div class='auth__input'>";
				echo "							<p>Address<span style='color:#dd2222;'>*</span></p>";
				echo "							<input type='text' class='auth__input__add' name='address1'>";
				echo "							<input type='text' name='address2'>";
				echo "							<p style='color: red;'>$addressError</p>";
				echo "						</div>";
				echo "						<div class='auth__input'>";
				echo "							<p>Username<span style='color:#dd2222;'>*</span></p>";
				echo "							<input type='text' name='username'>";
				echo "							<p style='color: red;'>$usernameError</p>";
				echo "						</div>";
				echo "						<div class='auth__input'>";
				echo "							<p>H/P Number<span style='color:#dd2222;'>*</span></p>";
				echo "							<input type='text' name='phone'>";
				echo "							<p style='color: red;'>$phoneError</p>";
				echo "						</div>";
				echo "						<div class='auth__input'>";
				echo "							<p>Email<span style='color:#dd2222;'>*</span></p>";
				echo "							<input type='text' name='email'>";
				echo "							<p style='color: red;'>$emailError</p>";
				echo "						</div>";
				echo "						<div class='auth__input'>";
				echo "							<p>Password<span style='color:#dd2222;'>*</span></p>";
				echo "							<input type='password' name='password'>";
				echo "							<p style='color: red;'>$passwordError</p>";
				echo "						</div>";
				echo "						<div class='auth__input'>";
				echo "							<p>Retype Password<span style='color:#dd2222;'>*</span></p>";
				echo "							<input type='password' name='retypePassword'>";
				echo "							<p style='color: red;'>$retypePasswordError</p>";
				echo "						</div>";
				echo "						<br>";
				echo "						<center>";
				echo "							<input type='hidden' name='submitted' value='true' />";
				echo "							<button type='submit' class='auth-btn'>REGISTER</button>";
				echo "						</center>";
				echo "						<br>";
				echo "						<div class='col-lg-12 col-md-12 text-center'>";
				echo "							<div class='header__top__right__auth'>";
				echo "								<br/><p><a href='sign_in.php' style='color: blue;'>Already have an account? Sign in here!</a></p>";
				echo "							</div>";
				echo "						</div>";
				echo "					</div>";
				echo "				</div>";
				echo "			</form>";
				echo "		</div>";
				echo "	</div>";
				echo "</section>";
			}
			//If there is no problem, display registration is successful
			else
			{
				echo "<section class='auth spad'>";
				echo "	<div class='container'>";
				echo "		<center";
				echo "			<p>Registration successful! Welcome to Team 18 Express.</p><br />";
				echo "			<button type='submit' class='auth-btn' onclick=\"location.href='./home.php'\">BOOK TICKETS NOW</button>";
				echo "		</center>";
				echo "	</div>";
				echo "</section>";
				
				//Store to database
				$dbc = mysqli_connect('localhost','root','');
				if(mysqli_select_db($dbc,'team18_express')){
					$query="INSERT INTO user (username,fname,lname,password,email,address,phone_num)
							VALUES('$username','$fName','$lName','$password','$email','$address','$phone')";
								
					if(@mysqli_query($dbc,$query)){
						mysqli_close($dbc);
						//redirect to login
						header("Location: sign_in.php"); 
						exit();
					}
					else{
						echo"ERROR! Table not found!";
						//create table?
						mysqli_close($dbc);
					}
				}
				else{
					echo"ERROR! Database not found!";
					mysqli_close($dbc);
				}
			}
		}
		//If form is not submitted, display the form
		else
		{
			echo "<section class='auth spad'>";
			echo "	<div class='container'>";
			echo "		<div class='auth__form'>";
			echo "			<h4>Registration form</h4>";
			echo "			<form action='./signup.php' method='post'>";
			echo "				<div class='row'>";
			echo "					<div class='col-lg-12'>";
			echo "						<div class='row'>";
			echo "							<div class='col-lg-6'>";
			echo "								<div class='auth__input'>";
			echo "									<p>Fist Name<span style='color:#dd2222;'>*</span></p>";
			echo "									<input type='text' name='fName'>";
			echo "								</div>";
			echo "							</div>";
			echo "							<div class='col-lg-6'>";
			echo "								<div class='auth__input'>";
			echo "									<p>Last Name<span style='color:#dd2222;'>*</span></p>";
			echo "									<input type='text' name='lName'>";
			echo "								</div>";
			echo "							</div>";
			echo "						</div>";
			echo "						<div class='auth__input'>";
			echo "							<p>Address<span style='color:#dd2222;'>*</span></p>";
			echo "							<input type='text' class='auth__input__add' name='address1'>";
			echo "							<input type='text' name='address2'>";
			echo "						</div>";
			echo "						<div class='auth__input'>";
			echo "							<p>Username<span style='color:#dd2222;'>*</span></p>";
			echo "							<input type='text' name='username'>";
			echo "						</div>";
			echo "						<div class='auth__input'>";
			echo "							<p>H/P Number<span style='color:#dd2222;'>*</span></p>";
			echo "							<input type='text' name='phone'>";
			echo "						</div>";
			echo "						<div class='auth__input'>";
			echo "							<p>Email<span style='color:#dd2222;'>*</span></p>";
			echo "							<input type='text' name='email'>";
			echo "						</div>";
			echo "						<div class='auth__input'>";
			echo "							<p>Password<span style='color:#dd2222;'>*</span></p>";
			echo "							<input type='password' name='password'>";
			echo "						</div>";
			echo "						<div class='auth__input'>";
			echo "							<p>Retype Password<span style='color:#dd2222;'>*</span></p>";
			echo "							<input type='password' name='retypePassword'>";
			echo "						</div>";
			echo "						<br>";
			echo "						<center>";
			echo "							<input type='hidden' name='submitted' value='true' />";
			echo "							<button type='submit' class='auth-btn'>REGISTER</button>";
			echo "						</center>";
			echo "						<br>";
			echo "						<div class='col-lg-12 col-md-12 text-center'>";
			echo "							<div class='header__top__right__auth'>";
			echo "								<br/><p><a href='sign_in.php' style='color: blue;'>Already have an account? Sign in here!</a></p>";
			echo "							</div>";
			echo "						</div>";
			echo "					</div>";
			echo "				</div>";
			echo "			</form>";
			echo "		</div>";
			echo "	</div>";
			echo "</section>";
		}
		
		//Footer
		include("footer.php");
	?>


    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

 

</body>

</html>