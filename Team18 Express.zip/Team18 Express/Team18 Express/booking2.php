<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reservations</title>    

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/booking.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
	<?php
		include("header.php");
	
		/* Breadcrumb Section Begin */
		echo "<section class='breadcrumb-section set-bg' data-setbg='img/about-us1.jpg'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12 text-center'>";
		echo "				<div class='breadcrumb__text'>";
		echo "					<br><br><br><br><h2 style='color:white; font-size:80px'>Reservations</h2><br>";
		echo "					<h5 style='color: white'>Book your bus ticket now!</h5><br><br><br><br>";
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</section>";
		/* Breadcrumb Section End */
		
		echo "<div class='booking spad'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12'>";
		echo "				<div class='booking__form'>";
		echo "					<h4>Booking details</h4>";
								//$_SESSION['id']
		                        if(isset($_POST['submitted'])){
									
									$tempalpha=chr(rand(65,90)).chr(rand(65,90)).chr(rand(65,90));
									$tempnum=rand(0,9).rand(0,9).rand(0,9);
									$booking_num=$tempalpha.$tempnum;

									$ticket_quantity=$_POST['ticket_quantity'];
									$booking_price=50*$ticket_quantity;
									$select_date=$_POST['select_date'];
									$booking_status='Successfully Booked';
	
									$dbc = mysqli_connect('localhost','root','');
									@mysqli_select_db($dbc,'team18_express');
									if($dbc){
										$result=mysqli_query($dbc,"SELECT user_id,username FROM user");
										while($row=mysqli_fetch_array($result)){
											if($_SESSION['id']==$row['username']){
												$user_id=$row['user_id'];
												$found=true;
											}
										}
									}
									
									$route_id=$_POST['route_id'];
									
		echo "						<p>Booking reference number: $booking_num</p>";//
		echo "						<p>Username: ".$_SESSION['id']."</p>";
									$result=mysqli_query($dbc,"SELECT r.route_id,b.bus_name FROM route r JOIN bus b ON (r.bus_id=b.bus_id) WHERE route_id=$route_id");
									$row=mysqli_fetch_array($result);
		echo "						<p>Bus name: ".$row['bus_name']."</p>";//
									$bus_name=$row['bus_name'];
									$route_id=$row['route_id'];
		echo "						<p>Departure date: $select_date</p>";//
									$result=mysqli_query($dbc,"SELECT route_name,departure,destination FROM route WHERE route_id=$route_id");
									$row=mysqli_fetch_array($result);
		echo "						<p>Route name: ".$row['route_name']."</p>";	//
									$route_name=$row['route_name'];
		echo "						<p>Departure: ".$row['departure']."</p>";//
									$departure=$row['departure'];
		echo "						<p>Destination: ".$row['destination']."</p>";//
									$destination=$row['destination'];
		echo "						<p>Ticket quantity: $ticket_quantity</p>";//
		echo "						<p>Total price: $booking_price</p>";
									
									if(!isset($_SESSION['cart'])){
										$_SESSION['cart'] = array();
									}
									
									$_SESSION['cart'][$booking_num] = array('booking_num' => $booking_num, 'bus_name' => $bus_name, 'departure_date' => $select_date,
									'route_name' => $route_name, 'departure' => $departure, 'destination' => $destination, 'ticket_quantity' => $ticket_quantity,'route_id'=>$route_id);
									
									print"<form method='post' action='shoppingcart.php?action=add&booking_num=$booking_num'>
									<center><button type='submit' class='booking-btn'>Add To Cart</button></center>";
									
									mysqli_close($dbc);
                                }
                                else if(!empty($_SESSION['id'])){
									$departure_date=$_POST['departure_date'];
									$unixTimestamp = strtotime($departure_date);
									$weekday = date("l", $unixTimestamp);
									$found=false;
									
		echo "						<form action='booking2.php' method='post'>";
		echo "							<div class='booking__input'>";
		echo "								<p>Route:</p>";
		echo "								<select name='route_id'>";
		echo "									<option value=''>Select route</option>";
												$dbc = mysqli_connect('localhost','root','');
												@mysqli_select_db($dbc,'team18_express');
												$result=mysqli_query($dbc,"SELECT route_id,route_name,departure,destination,weekday FROM route");
												while($row=mysqli_fetch_array($result)){
													if($row['weekday']==$weekday){
														$id=$row['route_id'];
														print"<option value='$id'>".$row['route_name']." | Depature:".$row['departure']." | Destination:".$row['destination']."</option>";
														$found=true;
													}
												}
												if($found==false){
		echo "										<option value=''>No available route</option>";
												}
												mysqli_close($dbc);
		echo "								</select>";
		echo "							</div>";
		echo "							<br /><br /><br />";
		echo "							<div class='booking__input'>";
		echo "								<p>Quantity:</p>";
		echo "								<input type='number' name='ticket_quantity' min='1' step='1' value='1' />";
		echo "							</div>";
		echo "							<input type='hidden' name='submitted' value='true' />";
		echo "							<input type='hidden' name='select_date' value='$departure_date' />";
		echo "							<center><button type='submit' class='booking-btn'>Book Now</button></center>";
		echo "						</form>";
		                        }
								else{
		echo "					You have to be logged in to access this page!";		
								}
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</div>";
		
		include("footer.php");
	?>

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
	</body>
</html>