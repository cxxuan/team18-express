<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <title>Purchase History</title>

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
<?php

	//Header
	include("header.php");
	
	/* Breadcrumb Section Begin */
	echo "<div class='hero__item set-bg' data-setbg='img/about-us1.jpg'>";
		echo "<div class='col-lg-12 text-center'>";
		echo "<div class='breadcrumb__text'>";
			echo "<h2 style='color:white; font-size:80px'>Purchase History</h2>";
		echo "</div>";
		echo "</div>";
	echo "</div>";
	/* Breadcrumb Section End */
	
	if(!empty($_SESSION['id'])){
	
	$dbc = mysqli_connect('localhost','root','');
	@mysqli_select_db($dbc,'team18_express');
	if($dbc){
		$result=mysqli_query($dbc,"SELECT * FROM booking INNER JOIN user ON booking.user_id = user.user_id");
		echo"<table align='center'>
						<tr>
							<th>Booking Num &nbsp&nbsp&nbsp</th>
							<th>Booking Date &nbsp&nbsp&nbsp</th>
							<th>Ticket Quantity &nbsp&nbsp&nbsp</th>
							<th>Total Price</th>
						<tr>";
					$i=0;
                    while($row=mysqli_fetch_array($result)){
						if($row['username']==$id){
						echo"
						<tr>
							<td align='center'>
							" . $row['booking_num']. "
							</td>
							<td align='center'>
							".$row['booking_date']. "					
       		                </td>
							<td align='center'>
							" . $row['ticket_quantity']. "
							</td>
							<td align='center'>
							".$row['booking_price']. "					
       		                </td>
						</tr>";	
						}
	                }
					echo"</table>";
				}
				else{
					echo"query failed";
				}
			
			mysqli_close($dbc);
	}
	else{
		echo"You have to be logged in to view this page";
	}
	
	//Footer
	include("footer.php");

    echo"<script src='js/jquery-3.3.1.min.js'></script>";
    echo"<script src='js/bootstrap.min.js'></script>";
    echo"<script src='js/jquery.nice-select.min.js'></script>";
    echo"<script src='js/jquery-ui.min.js'></script>";
    echo"<script src='js/jquery.slicknav.js'></script>";
    echo"<script src='js/mixitup.min.js'></script>";
    echo"<script src='js/owl.carousel.min.js'></script>";
    echo"<script src='js/main.js'></script>";


?>
</body>

</html>