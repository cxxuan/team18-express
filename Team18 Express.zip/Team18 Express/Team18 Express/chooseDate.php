<?php
if(isset($_POST['submitted'])){//if user have selected a date
	
	//get the date in yyyy-mm-dd format
	$date = $_POST['departDate']; 

	//parse the String into a timestamp
	$timestamp = strtotime($date);
	
	//get day
	$day = date('l', $timestamp); 
?>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<!DOCTYPE html>
<html lang="en">

<head>
<title>Destinations</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Css Styles -->
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
	<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
	<link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
	<link rel="stylesheet" href="css/nice-select.css" type="text/css">
	<link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
	<link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
	<link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/ps_style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
  color: #000000;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>

<body style="background-color:<?php echo "$background_color"; ?>">
<?php

	//retrieve and display the header
	include ('header.php');
	
	/* Breadcrumb Section Begin */
	echo "<div class='hero__item set-bg' data-setbg='img/about-us1.jpg'>";
		echo "<div class='col-lg-12 text-center'>";
		echo "<div class='breadcrumb__text'>";
			echo "<h2 style='color:white; font-size:80px'>Destinations</h2>";
		echo "</div>";
		echo "</div>";
	echo "</div>";
	/* Breadcrumb Section End */
	
	//print out the table's header / fields first
	echo"<table>";
		echo"<tr>";
			echo"<th>Destinations</th>";
			echo"<th>Action</th>";
		echo"</tr>";

		if($dbc = mysqli_connect('localhost', 'root', '')){//if succesfully connect to database server
		
			if (!mysqli_select_db($dbc, 'team18_express')){//if cannot select the database
				
				//print out error message
				echo "<p>Could not select the database because: " . mysqli_error($dbc) . ".</p>";

			}else{//if can select the desired database

				//define the query
				$query = "SELECT destination FROM route WHERE (weekday = '$day')";

				//execute the query
				if ($result = mysqli_query($dbc, $query)){
					
					//turn each row of information into an array called $row
					while($row = mysqli_fetch_array($result, MYSQLI_ASSOC)){
						
						//list down the destination names in a table
						echo "<tr>";
						echo "<td>{$row['destination']}</td>";
						//action link to allow user to view available buses
					    echo "<td><a href=\"buses.php?destination={$row['destination']}\">view available buses</a></td>";
					    echo "</tr>";

					}	
					
				}else{//if could not retrieve the data
					
					//print error message
					echo "<p>Could not retrieve the data because: <br />" . mysqli_error($dbc) . ".</p>";
					echo "<p>The query being run was : " . $query . "</p>";
					
				}
			}
			
			//close the connection 
			mysqli_close($dbc);
		
		}else{//if cannot connect to database server
		
			//print error message
			echo "<p>Could not connect to MySQL: " . mysqli_error($dbc) . ".</p>";
			
		}	
	
	//close table tag
	echo "</table>";
	
	//retrieve and display the header
	include ('footer.php');
?>

	<!-- Js Plugins -->
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/jquery.slicknav.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>
	
</body>
</html>
<?php
	
}else{//if user have not chosen a date (form haven't submit)
	
	//get today's date
	$currentDate = date('Y-m-d');
	
	//display the form 
	echo "<!DOCTYPE html>";
	echo "<html lang='en'>";

	echo "<head>";
		echo "<meta charset='utf-8'>";
		echo "<meta http-equiv='X-UA-Compatible' content='IE=edge'>";
		echo "<meta name='viewport' content='width=device-width, initial-scale=1'>";
		
		echo "<title>View Destinations</title>";
		
		echo "<link href='https://fonts.googleapis.com/css?family=Montserrat:400,700' rel='stylesheet'>";
		echo "<link type='text/css' rel='stylesheet' href='css/view_bootstrap.min.css' />";
		echo "<link type='text/css' rel='stylesheet' href='css/view_style.css' />";		
	echo "</head>";

	echo "<body>";
		echo "<div id='booking' class='section'>";
			echo "<div class='section-center'>";
				echo "<div class='container'>";
					echo "<div class='row'>";
						echo "<div class='col-md-7 col-md-push-5'>";
							echo "<div class='booking-cta'>";
								echo "<h1>View Our Destinations</h1>";
								echo "<p>Buses have always been an excellent option to take when traveling from ";
								echo "one place to another in Malaysia. In the good old days, every bus ticket ";
								echo "that was sold was either through a travel agent or at a bus ticket counter.";
								echo "But, thanks to the internet, booking a bus has become a lot simpler. Malaysia offers thousands of wonderful ";
								echo "tourist destinations and buses, with a great passenger capacity and safety, are the best mode of transportation. ";
								echo "</p>";
							echo "</div>";
						echo "</div>";
							echo "<div class='col-md-4 col-md-pull-7'>";
								echo "<div class='booking-form'>";
									//form starts here
									echo "<form method='post' action='chooseDate.php'>";
										echo "<div class='row'>";
											echo "<div class='col-sm-12'>";
												echo "<div class='form-group'>";
													echo "<span class='form-label'>Departure Date</span>";
														echo "<input class='form-control' type='date' name='departDate' min='$currentDate' required>";
														echo "</div>";
													echo "</div>";
												echo "</div>";
											echo "<div class='form-btn'>";
										echo "<button class='submit-btn'>Check destinations</button>";
								echo "<input type='hidden' name='submitted' value='true' />";
							echo "</div>";
								echo "</form>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";
			echo "</div>";
		echo "</div>";
	echo "</body>";
	echo "</html>";
}
	
?>

<!-- This templates was made by Colorlib (https://colorlib.com) -->
