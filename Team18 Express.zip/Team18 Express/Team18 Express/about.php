<!DOCTYPE html>
<html lang="en">

<head>
	<title>About Us</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<!-- Css Styles -->
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
	<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
	<link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
	<link rel="stylesheet" href="css/nice-select.css" type="text/css">
	<link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
	<link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
	<link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/ps_style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
	
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
	<?php
	/*Header*/
	include ('header.php');
	
	/*Breadcrumb Section Begin*/
	echo "<div class='hero__item set-bg' data-setbg='img/about-us1.jpg'>";
		echo "<div class='col-lg-12 text-center'>";
		echo "<div class='breadcrumb__text'>";
			echo "<h2 style='color:white; font-size:80px'>About Us</h2>";
			echo "<h5 style='color: white'>Find out more about Team18 Express!</h5>";
		echo "</div>";
		echo "</div>";
	echo "</div>";
	/*Breadcrumb Section End*/
	
	/* Why Choose Us Section */
	echo "<section class='ftco-section ftco-no-pt ftco-no-pb'>";
		echo "<div class='container'>";
			echo "<div class='row d-flex no-gutters'>";
				echo "<div class='col-md-5 d-flex'>";
					echo "<div class='img img-video d-flex align-self-stretch align-items-center justify-content-center justify-content-md-center mb-4 mb-sm-0' style='background-image:url(img/about-us-n.jpg); background-size: 450px 450px;'>";
					echo "</div>";
				echo "</div>";
				echo "<div class='col-md-7 pl-md-5 py-md-5'>";
					echo "<div class='heading-section pt-md-5'>";
						echo "<h2 class='mb-4'>Why Choose Us ?</h2>";
					echo "</div>";
					echo "<div class='row'>";
						echo "<div class='col-md-6 services-2 w-100 d-flex'>";
							echo "<div style='background-color:#e60000;' class='icon d-flex align-items-center justify-content-center'><i class='material-icons' style='font-size:35px;color:white;'>directions_bus</i></div>";
							echo "<div class='text pl-3'>";
								echo "<h4>Bus Tickets On-The-Go</h4>";
								echo "<p>Skip the long queues and book your bus ticket from your phone anytime, anywhere. We make it convenient for you. </p>";
							echo "</div>";
							
						echo "</div>";
						
						echo "<div class='col-md-6 services-2 w-100 d-flex'>";
							echo "<div style='background-color:#e60000;' class='icon d-flex align-items-center justify-content-center'><i class='material-icons' style='font-size:35px;color:white;'>emoji_objects</i></div>";
							echo "<div class='text pl-3'>";
								echo "<h4>Ticket Counter Prices Guaranteed</h4>";
								echo "<p>Our bus tickets are sold at the latest and compare prices as physical ticket counters with no extra service charges. </p>";
							echo "</div>";
						echo "</div>";
						echo "<div class='col-md-6 services-2 w-100 d-flex'>";
							echo "<div style='background-color:#e60000;' class='icon d-flex align-items-center justify-content-center'><i class='material-icons' style='font-size:35px;color:white;'>explore</i></div>";
							echo "<div class='text pl-3'>";
								echo "<h4>Personalising Your Bus Travels</h4>";
								echo "<p>Travel to over 1,200 routes across 700 destinations within Malaysia and Singapore aboard your favourite operators. </p>";
							echo "</div>";
						echo "</div>";
						echo "<div class='col-md-6 services-2 w-100 d-flex'>";
							echo "<div style='background-color:#e60000;' class='icon d-flex align-items-center justify-content-center'><i class='material-icons' style='font-size:35px;color:white;'>eco</i></div>";
							echo "<div class='text pl-3'>";
								echo "<h4>24 Hour Helpline</h4>";
								echo "<p>Always there in the case of last minute changes. We would be delighted to help you out.</p>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";
			echo "</div>";
		echo "</div>";
	echo "</section>";
	/* Why Choose Us Section*/
	
	/* Red banner section start */
	echo "<section class='ftco-counter' id='section-counter' style='background-color:#e60000;'>";
		echo "<div class='container'>";
			echo "<div class='row'>";
				echo "<div class='col-md-6 col-lg-3 d-flex justify-content-center counter-wrap'>";
					echo "<div class='block-18 text-center'>";
						echo "<div class='text'>";
							echo "<strong class='number' data-number='50'>25 M</strong>";
						echo "</div>";
						echo "<div class='text'>";
							echo "<span>CUSTOMERS</span>";
						echo "</div>";
					echo "</div>";
				echo "</div>";
				echo "<div class='col-md-6 col-lg-3 d-flex justify-content-center counter-wrap'>";
					echo "<div class='block-18 text-center'>";
						echo "<div class='text'>";
							echo "<strong class='number' data-number='8500'>2450</strong>";
						echo "</div>";
						echo "<div class='text'>";
							echo "<span>OPERATORS</span>";
						echo "</div>";
					echo "</div>";
				echo "</div>";
				echo "<div class='col-md-6 col-lg-3 d-flex justify-content-center counter-wrap'>";
					echo "<div class='block-18 text-center'>";
						echo "<div class='text'>";
							echo "<strong class='number' data-number='20'>1200</strong>";
						echo "</div>";
						echo "<div class='text'>";
							echo "<span>ROUTES</span>";
						echo "</div>";
					echo "</div>";
				echo "</div>";
				echo "<div class='col-md-6 col-lg-3 d-flex justify-content-center counter-wrap'>";
					echo "<div class='block-18 text-center'>";
						echo "<div class='text'>";
							echo "<strong class='number' data-number='50' style='color:white'>200 M</strong>";
						echo "</div>";
						echo "<div class='text'>";
							echo "<span>BUS TICKETS SOLD</span>";
						echo "</div>";
					echo "</div>";
				echo "</div>";
			echo "</div>";
		echo "</div>";
	echo "</section>";
	/* Red banner section end */


	echo "<section class='ftco-section bg-light ftco-faqs'>";
		echo "<div class='container'>";
			echo "<div class='row'>";
				echo "<div class='col-lg-6 order-md-last'>";
					echo "<div class='img img-video d-flex align-self-stretch align-items-center justify-content-center justify-content-md-center mb-4 mb-sm-0' style='background-image:url(img/about-us.jpg);'>";
						echo "<a href='https://vimeo.com/45830194' class='icon-video popup-vimeo d-flex justify-content-center align-items-center'>";
							echo "<span class='fa fa-play'></span>";
						echo "</a>";
					echo "</div>";
					echo "<div class='d-flex mt-3'>";
						echo "<div class='img img-2 mr-md-2' style='background-image:url(img/about-us3.jpg);'></div>";
						echo "<div class='img img-2 ml-md-2' style='background-image:url(img/about-us2.jpg);'></div>";
					echo "</div>";
				echo "</div>";

				echo "<div class='col-lg-6'>";
					echo "<div class='heading-section mb-5 mt-5 mt-lg-0'>";
						echo "<h2 class='mb-3'>Frequently Asks Questions</h2>";
						echo "<p>Our most frequently asked questions can be found below.</p>";
					echo "</div>";
					echo "<div id='accordion' class='myaccordion w-100' aria-multiselectable='true'>";
						echo "<div class='card'>";
							echo "<div class='card-header p-0' id='headingOne'>";
								echo "<h2 class='mb-0'>";
									echo "<button href='#collapseOne' class='d-flex py-3 px-4 align-items-center justify-content-between btn btn-link' data-parent='#accordion' data-toggle='collapse' aria-expanded='true' aria-controls='collapseOne' style='background-color:#e60000;'>";
										echo "<p class='mb-0'style='color:white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Are there any luggage restrictions?</p>";
										echo "<i class='fa' aria-hidden='true'></i>";
									echo "</button>";
								echo "</h2>";
							echo "</div>";
							echo "<div class='collapse show' id='collapseOne' role='tabpanel' aria-labelledby='headingOne'>";
								echo "<div class='card-body py-3 px-0'>";
									echo "<p style='margin: 35px;'>Baggage not exceeding 10 kg per passenger. The size is limited to 55cm x 35cm x 25 cm. We reserve the right to refuse any luggage beyond.</p>";
								echo "</div>";
							echo "</div>";
						echo "</div>";

						echo "<div class='card'>";
							echo "<div class='card-header p-0' id='headingTwo' role='tab'>";
								echo "<h2 class='mb-0'>";
									echo "<button href='#collapseTwo' class='d-flex py-3 px-4 align-items-center justify-content-between btn btn-link' data-parent='#accordion' data-toggle='collapse' aria-expanded='false' aria-controls='collapseTwo' style='background-color:#e60000;'>";
										echo "<p class='mb-0' style='color:white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Do i need a Visa?</p>";
										echo "<i class='fa' aria-hidden='true'></i>";
									echo "</button>";
								echo "</h2>";
							echo "</div>";
							echo "<div class='collapse' id='collapseTwo' role='tabpanel' aria-labelledby='headingTwo'>";
								echo "<div class='card-body py-3 px-0'>";
									echo "<p style='margin: 35px;'>Malaysian and Singaporean do not need to have a visa for entry into Singapore or Malaysia.</p>";
								echo "</div>";
							echo "</div>";
						echo "</div>";

						echo "<div class='card'>";
							echo "<div class='card-header p-0' id='headingThree' role='tab'>";
								echo "<h2 class='mb-0'>";
									echo "<button href='#collapseThree' class='d-flex py-3 px-4 align-items-center justify-content-between btn btn-link' data-parent='#accordion' data-toggle='collapse' aria-expanded='false' aria-controls='collapseThree' style='background-color:#e60000;'>";
										echo "<p class='mb-0' style='color:white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Can the coach wait for me if I turn up late?</p>";
										echo "<i class='fa' aria-hidden='true'></i>";
									echo "</button>";
								echo "</h2>";
							echo "</div>";
							echo "<div class='collapse' id='collapseThree' role='tabpanel' aria-labelledby='headingTwo'>";
								echo "<div class='card-body py-3 px-0'>";
									echo "<p style='margin: 35px;'>Our buses leave on time and cannot wait at the expense of other passengers. Please be at our departure office at least 15 minutes before departure. For tickets purchased online or confirmation by phone, you are required to be at our office at least 30 minutes before departure time.</p>";
								echo "</div>";
							echo "</div>";
						echo "</div>";

						echo "<div class='card'>";
							echo "<div class='card-header p-0' id='headingFour' role='tab'>";
								echo "<h2 class='mb-0'>";
									echo "<button href='#collapseFour' class='d-flex py-3 px-4 align-items-center justify-content-between btn btn-link' data-parent='#accordion' data-toggle='collapse' aria-expanded='false' aria-controls='collapseFour' style='background-color:#e60000;'>";
										echo "<p class='mb-0'style='color:white'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Can I get a refund for cancellations?</p>";
										echo "<i class='fa' aria-hidden='true'></i>";
									echo "</button>";
								echo "</h2>";
							echo "</div>";
							echo "<div class='collapse' id='collapseFour' role='tabpanel' aria-labelledby='headingTwo'>";
								echo "<div class='card-body py-3 px-0'>";
									echo "<p style='margin: 35px;'>No cancellation or refund is allowed. You are only to allow amend the departure date.</p>";
								echo "</div>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</div>";
			echo "</div>";
		echo "</div>";
	echo "</section>";
	
	/*Footer*/
	include ('footer.php');
	?>
	
	<!-- Js Plugins -->
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/jquery.slicknav.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

</body>
</html>