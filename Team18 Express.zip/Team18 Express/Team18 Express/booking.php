<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Reservations</title>    

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/booking.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
	<?php
		//get today's date
		$currentDate = date('Y-m-d');
		
		include("header.php");
	
		/* Breadcrumb Section Begin */
		echo "<section class='breadcrumb-section set-bg' data-setbg='img/about-us1.jpg'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12 text-center'>";
		echo "				<div class='breadcrumb__text'>";
		echo "					<br><br><br><br><h2 style='color:white; font-size:80px'>Reservations</h2><br>";
		echo "					<h5 style='color: white'>Book your bus ticket now!</h5><br><br><br><br>";
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</section>";
		/* Breadcrumb Section End */
		
		echo "<div class='booking spad'>";
		echo "	<div class='container'>";
		echo "		<div class='row'>";
		echo "			<div class='col-lg-12'>";
		echo "				<div class='booking__form'>";
		echo "					<h4>Book your ticket</h4>";
								if(!empty($_SESSION['id'])){								
		echo "						<form action='booking2.php' method='post'>";
		echo "							<div class='booking__input'>";
		echo "								<p>Departure date:</p>";
		echo "								<input type='date' name='departure_date' min='$currentDate' required/>";
		echo "							</div>";
		echo "							<center><button type='submit' class='booking-btn'>Continue</button></center>";
		echo "						</form>";
		                        }
								else{
		echo "					You have to be logged in to access this page!";		
								}
		echo "				</div>";
		echo "			</div>";
		echo "		</div>";
		echo "	</div>";
		echo "</div>";
		
		include("footer.php");
	?>

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
	</body>
</html>
