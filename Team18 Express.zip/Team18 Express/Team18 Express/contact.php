<?php
//if the form was submitted
if(isset($_POST['submitted'])){
	
	//get the form data
	$name=filter_input(INPUT_POST, 'name');
	$email=filter_input(INPUT_POST, 'email');
	$message=filter_input(INPUT_POST, 'message');

	//validation for name
	if(empty($name)){//if the empty function returns true
	
		if($name == "0"){//if user inputs '0'
		
			//display error message
			$name_error="Name should only contain alphabetic characters and spaces.";
			
		}else {//if name field is empty
		
			//display error message
			$name_error="Please enter your name.";
			
		}
		
	}else if(ctype_alpha(str_replace(' ', '', $name)) === false){//if user enters anything else than alphabetic characters and spaces
	
		//display error message
		$name_error="Name should only contain alphabetic characters and spaces.";
		
	}
	
	//validation for email
	//if email field is empty
	if(empty($email)){
		
		//display error message
		$email_error="Please enter your email address."; 
		
	}
	
	//validation for message
	//if message field is empty
	if(empty($message) && $message != "0"){
		
		//display error message
		$message_error="Please enter your message."; 
		
	}
	
	//if the submitted form has no errors
	if(empty($name_error) && empty($email_error) && empty($message_error)){
		
		//redirect user to another page that congratulates
		//user for succeeding in sending his/her message
		header('Location: contact_success.php'); 
		
		//cancel the execution of the script
		exit();
		
	}
	
}
?>

<!DOCTYPE html>
<html lang="zxx">

<head>
	<meta charset="UTF-8">
	<meta name="description" content="Ogani Template">
	<meta name="keywords" content="Ogani, unica, creative, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Contact Us</title>	

	<!-- Css Styles -->
	<link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
	<link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
	<link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
	<link rel="stylesheet" href="css/nice-select.css" type="text/css">
	<link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
	<link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
	<link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/flaticon.css">
	<link rel="stylesheet" href="css/ps_style.css">
	<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
	<?php	
	//Retrieve and display webpage header
	include ('header.php');		

	/*Breadcrumb Section Begin*/
	echo "<div class='hero__item set-bg' data-setbg='img/about-us1.jpg'>";
		echo "<div class='col-lg-12 text-center'>";
		echo "<div class='breadcrumb__text'>";
			echo "<h2 style='color:white; font-size:80px;'>Contact Us</h2>";
			echo "<h5 style='color: white'>Feel free to contact us if you have any questions.</h5>";
		echo "</div>";
		echo "</div>";
	echo "</div>";
	/*Breadcrumb Section End*/

	/* Contact Section Begin */
	echo "<section class='contact spad'>";
		echo "<div class='container'>";
			echo "<div class='row'>";
				echo "<div class='col-lg-3 col-md-3 col-sm-6 text-center'>";
					echo "<div class='contact__widget'>";
						echo "<i class='material-icons' style='font-size:35px;color:#e60000;'>call</i>";
						echo "<h4>Phone</h4>";
						echo "<p>04-1234567</p>";
					echo "</div>";
				echo "</div>";
				echo "<div class='col-lg-3 col-md-3 col-sm-6 text-center'>";
					echo "<div class='contact__widget'>";
						echo "<i class='material-icons' style='font-size:35px;color:#e60000;'>room</i>";
						echo "<h4>Address</h4>";
						echo "<p>88, Express Road, 11900 Penang</p>";
					echo "</div>";
				echo "</div>";
				echo "<div class='col-lg-3 col-md-3 col-sm-6 text-center'>";
					echo "<div class='contact__widget'>";
						echo "<i class='material-icons' style='font-size:35px;color:#e60000;'>access_time</i>";
						echo "<h4>Open time</h4>";
						echo "<p>08:00 AM to 11:00 PM</p>";
					echo "</div>";
				echo "</div>";
				echo "<div class='col-lg-3 col-md-3 col-sm-6 text-center'>";
					echo "<div class='contact__widget'>";
						echo "<i class='material-icons' style='font-size:35px;color:#e60000;'>mail</i>";
						echo "<h4>Email</h4>";
						echo "<p>team18express@gmail.com</p>";
					echo "</div>";
				echo "</div>";
			echo "</div>";
		echo "</div>";
	echo "</section>";
	/* Contact Section End */

	/* Map Begin */
	echo "<div class='map'>";
		echo "<iframe src='https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d49116.39176087041!2d-86.41867791216099!3d39.69977417971648!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x886ca48c841038a1%3A0x70cfba96bf847f0!2sPlainfield%2C%20IN%2C%20USA!5e0!3m2!1sen!2sbd!4v1586106673811!5m2!1sen!2sbd' height='500' style='border:0;' allowfullscreen='' aria-hidden='false' tabindex='0'>";
		echo "</iframe>";
		echo "<div class='map-inside'>";
			echo "<i class='icon_pin'></i>";
			echo "<div class='inside-widget'>";
				echo "<h4>Team 18 Express</h4>";
				echo "<ul>";
					echo "<li>Phone: 04-1234567</li>";
					echo "<li>Add: 88, Express Road, 11900 Penang</li>";
				echo "</ul>";
			echo "</div>";
		echo "</div>";
	echo "</div>";
	/* Map End */
	
	//persist form data
	$persistName = isset($_POST['name']) ? $_POST['name'] : '';
	$persistEmail = isset($_POST['email']) ? $_POST['email'] : '';
	$persistMessage = isset($_POST['message']) ? $_POST['message'] : '';
	
	//prevent html injection or XSS attacks
	$persistName=htmlentities($persistName);
	$persistEmail=htmlentities($persistEmail);
	$persistMessage=htmlentities($persistMessage);
	
	/* Contact Form Begin */
	echo "<div class='contact-form spad'>";
		echo "<div class='container'>";
			echo "<div class='row'>";
				echo "<div class='col-lg-12'>";
					echo "<div class='contact__form__title'>";
						echo "<h2>Leave a Message</h2>";
					echo "</div>";
				echo "</div>";
			echo "</div>";
			echo "<form method='post' action='contact.php'>";
				echo "<div class='row'>";
					echo "<div class='col-lg-6 col-md-6'>";
						echo "<input type='text' name='name' value='$persistName' placeholder='Your name'>";
						//if there is an error in name field in the last form submission, display it
						if(isset($name_error)){
							echo "<p><font color='red'>$name_error</font></p>";
						}
					echo "</div>";
					echo "<div class='col-lg-6 col-md-6'>";
						echo "<input type='email' name='email' value='$persistEmail' placeholder='Your email'>";
						//if there is an error in email field in the last form submission, display it
						if(isset($email_error)){
							echo "<p><font color='red'>$email_error</font></p>";
						}
					echo "</div>";
					echo "<div class='col-lg-12 text-center'>";
						echo "<textarea placeholder='Your message' name='message'>$persistMessage</textarea>";
						//if there is an error in message field in the last form submission, display it
						if(isset($message_error)){
							echo "<p><font color='red'>$message_error</font></p>";
						}
					echo "</div>";
					echo "<div class='col-md-12 text-center'>";
						echo "<button type='submit' class='site-btn' style='background-color:#e60000;'>SEND MESSAGE</button>";
						echo "<input type='hidden' name='submitted' value='true' />";
					echo "</div>";
				echo "</div>";
			echo "</form>";
		echo "</div>";
	echo "</div>";
	/* Contact Form End */
	
	//Retrieve and display the webpage footer
	include ('footer.php');
	?>
	
	<!-- Js Plugins -->
	<script src="js/jquery-3.3.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.nice-select.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/jquery.slicknav.js"></script>
	<script src="js/mixitup.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/main.js"></script>

</body>
</html>