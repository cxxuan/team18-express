<?php
	//Cookies
	//if cookies are not set by the user
	if (!isset($_COOKIE['background_color'])) {
		$background_color = 'White';
	}
	//if cookies are set by the user
	else {
		$background_color = $_COOKIE['background_color'];
	}
?>