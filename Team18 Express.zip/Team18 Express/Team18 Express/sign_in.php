<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
    <title>Sign In</title>		

    <!-- CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/sign_in.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
<?php
    //Header Section Begins
    include ('header.php');
    //Header Section Ends	  
	
	//Sign In Header Section Begins
    echo "<section class='breadcrumb-section set-bg' data-setbg='img/about-us3.jpg'>";
        echo "<div class='container'>";
            echo "<div class='row'>";
                echo "<div class='col-lg-12 text-center'>";
                    echo "<div class='breadcrumb__text'>";
                        echo "<br><br><br><br><h2 style='color:white; font-size:80px'>Sign In</h2><br>";
						echo "<h5 style='color: white'>Sign in to your account now!</h5><br><br><br><br>";
                    echo "</div>";
                echo "</div>";
            echo "</div>";
        echo "</div>";
    echo "</section>";
    //Sign In Header Section Ends
	
	//Sign In Form Begins
	echo "<section class='auth spad'>";
        echo "<div class='container'>";
            echo "<div class='row'>";
                echo "<div class='col-lg-12'>";
                    echo "<div class='auth__form'>";
                        echo "<h4>Sign In Form</h4>"; //Headings
                    echo "</div>";
                echo "</div>";
            echo "</div>";
			
			//Check whether variable is set or declared
			if (isset($_POST['submitted'])) {
				//Retrieve form data
				$id = $_POST['id'];
				$password = $_POST['password'];
				$idError = "";
				$passwordError = "";
				$id_passwordError = "";
				$problem = false; //Variable determining if there is any errors
				$found=false;
				
				if (empty($id) || empty($password)) {
					//Check whether ID is empty
					if (empty($id)) {
						$idError = "ID cannot be empty!";
						$problem = true;
					}

					//Check whether password is empty
					if (empty($password)) {
						$passwordError = "Password cannot be empty!";
						$problem = true;
					}
				}				
				else {
					//Retrieve data from database
					$dbc = mysqli_connect('localhost','root','');
					@mysqli_select_db($dbc,'team18_express');
					if($dbc){
						$result=mysqli_query($dbc,"SELECT username,password FROM user");
						while($row=mysqli_fetch_array($result)){
							if($id==$row['username']&&$password==$row['password']){
								$found=true;
							}
						}
						if($found==false){
							$id_passwordError = "Incorrect ID or Password entered!";
							$problem = true;
						}
					}										
				}
				
				//If there is problem, redisplay the form with appropriate error message
				if ($problem) {
					echo "<form method='post' action='sign_in.php'>";
						echo "<div class='row'>";						
							echo "<div class='col-lg-12 col-md-12'>";
								echo "<div class='auth__input'>";
									echo "<p>ID<span style='color:#dd2222;'>*</span></p>";
									echo "<input name='id' type='text'>"; //ID
									echo "<p style='color: red;'>$idError</p>";
								echo "</div>";	
							echo "</div>";						
							echo "<div class='col-lg-12 col-md-12'>";
								echo "<div class='auth__input'>";
									echo "<p>Password<span style='color:#dd2222;'>*</span></p>";
									echo "<input name='password' type='password'>"; //Password
									echo "<p style='color: red;'>$passwordError</p>";
									echo "<p style='color: red;'>$id_passwordError</p>";
								echo "</div>";
							echo "</div>";						
							echo "<div class='col-lg-12 text-center'>";
								echo "<input type='hidden' name='submitted' value='true'/>";
								echo "<button type='submit' class='site-btn'>SIGN IN</button>"; //Submit							
							echo "</div>";
							echo "<div class='col-lg-12 col-md-12 text-center'>";
								echo "<br/><br/><p>Sign in using:</p>";
								echo "<div class='footer__widget'>";
									echo "<div class='footer__widget__social'>";
										echo "<a href='https://www.facebook.com/'><i class='fa fa-facebook'></i></a>"; //Facebook
										echo "<a href='https://twitter.com/'><i class='fa fa-twitter'></i></a>"; //Twitter
										echo "<a href='https://www.linkedin.com/'><i class='fa fa-linkedin'></i></a>"; //LinkedIn
									echo "</div>";
								echo "</div>";
							echo "</div>";
							echo "<div class='col-lg-12 col-md-12 text-center'>";
								echo "<div class='header__top__right__auth'>";
									echo "<br/><p><a href='signup.php' style='color: blue;'>New user? Register here!</a></p>";
								echo "</div>";
							echo "</div>";
						echo "</div>";
					echo "</form>";
				}
				//If there is no problem,redirect user to Home page after successful login
				else {
					//Session
					if (isset($_POST['id'])) {
						session_start(); //Start the session
						
						//Store session variable values
						$_SESSION['id'] = $_POST['id'];
						$_SESSION['time'] = time();
						
						header('Location: home.php'); //Redirect user to home page
						exit(); //Exit
					}
				}

			}
			//Display form
			else {
				echo "<form method='post' action='sign_in.php'>";
					echo "<div class='row'>";						
						echo "<div class='col-lg-12 col-md-12'>";
							echo "<div class='auth__input'>";
								echo "<p>ID<span style='color:#dd2222;'>*</span></p>";
								echo "<input name='id' type='text'>"; //ID
							echo "</div>";	
						echo "</div>";						
						echo "<div class='col-lg-12 col-md-12'>";
							echo "<div class='auth__input'>";
								echo "<p>Password<span style='color:#dd2222;'>*</span></p>";
								echo "<input name='password' type='password'>"; //Password
							echo "</div>";
						echo "</div>";						
						echo "<div class='col-lg-12 text-center'>";
							echo "<input type='hidden' name='submitted' value='true'/>";
							echo "<button type='submit' class='site-btn'>SIGN IN</button>"; //Submit							
						echo "</div>";
						echo "<div class='col-lg-12 col-md-12 text-center'>";
							echo "<br/><br/><p>Sign in using:</p>";
							echo "<div class='footer__widget'>";
								echo "<div class='footer__widget__social'>";
									echo "<a href='https://www.facebook.com/'><i class='fa fa-facebook'></i></a>"; //Facebook
									echo "<a href='https://twitter.com/'><i class='fa fa-twitter'></i></a>"; //Twitter
									echo "<a href='https://www.linkedin.com/'><i class='fa fa-linkedin'></i></a>"; //LinkedIn
								echo "</div>";
							echo "</div>";
						echo "</div>";
						echo "<div class='col-lg-12 col-md-12 text-center'>";
							echo "<div class='header__top__right__auth'>";
								echo "<br/><p><a href='signup.php' style='color: blue;'>New user? Register here!</a></p>";
							echo "</div>";
						echo "</div>";
					echo "</div>";
				echo "</form>";
			}
			
        echo "</div>";
    echo "</div>";
	//Sign In Form Ends
	
	//Footer Section Begins
    include ('footer.php');
    //Footer Section Ends
?>

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
	
</body>

</html>