<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <title>Team18 Express</title>   

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
<?php

	//Header
	include("header.php");

    echo"<section class=hero'>";
        echo"<div class='container'>";
            echo"<div class='row>";
                echo"<div class='col-lg-12'>";
                    echo"<div class='hero__item set-bg' data-setbg='img/bus.jpg'>";
                        echo"<div class='hero__text'>";
                            echo"<span>New Fleet</span>";
                            echo"<h2>Travel In Luxury<br />With No Worries</h2>";
                            echo"<p>Only available in certain times</p>";
                            echo"<a href='booking.php' class='primary-btn'>BOOK NOW</a>";
                        echo"</div>";
                    echo"</div>";
                echo"</div>";
            echo"</div>";
        echo"</div>";
    echo"</section>";
	
    echo"<section class='featured spad'>";
        echo"<div class='container'>";
            echo"<div class='row'>";
                echo"<div class='col-lg-12'>";
                    echo"<div class='section-title'>";
                        echo"<h2>Popular Destinations</h2>";
                    echo"</div>";
                echo"</div>";
            echo"</div>";
            echo"<div class='row featured__filter'>";
               echo"<div class='col-lg-3'>";
                        echo"<div class='categories__item set-bg' data-setbg='img/kl.jpg'>";
                            echo"<h5><a href='booking.php'>Kuala Lumpur</a></h5>";
                        echo"</div>";
                    echo"</div>";
                    echo"<div class='col-lg-3'>";
                        echo"<div class='categories__item set-bg' data-setbg='img/pg.jpg'>";
                            echo"<h5><a href='booking.php'>Penang</a></h5>";
                        echo"</div>";
                    echo"</div>";
                    echo"<div class='col-lg-3'>";
                        echo"<div class='categories__item set-bg' data-setbg='img/jb.jpg'>";
                            echo"<h5><a href='booking.php'>Johor</a></h5>";
                        echo"</div>";
                    echo"</div>";
                    echo"<div class='col-lg-3'>";
                        echo"<div class='categories__item set-bg' data-setbg='img/trg.jpg'>";
                            echo"<h5><a href='booking.php'>Terengganu</a></h5>";
                        echo"</div>";
                    echo"</div>";
                    echo"</div>";
                echo"</div>";
            echo"</div>";
        echo"</div>";
    echo"</section>";
	
	 echo"<section class='from-blog spad'>";
        echo"<div class='container'>";
            echo"<div class='row'>";
                echo"<div class='col-lg-12'>";
                    echo"<div class='section-title from-blog__title'>";
                        echo"<h2>Looking for more info?</h2>";
                    echo"</div>";
                echo"</div>";
            echo"</div>";
            echo"<div class='row'>";
                echo"<div class='col-lg-4 col-md-4 col-sm-6'>";
                    echo"<div class='blog__item'>";
                        echo"<div class='blog__item__pic'>";
                            echo"<img src='img/about.jpg' alt=''>";
                        echo"</div>";
                        echo"<div class='blog__item__text'>";
                            echo"<h5><a href='about.php'>Learn more about us</a></h5>";
                            echo"<p>Looking to learn more about us?</p>";
                        echo"</div>";
                    echo"</div>";
                echo"</div>";
                echo"<div class='col-lg-4 col-md-4 col-sm-6'>";
                    echo"<div class='blog__item'>";
                        echo"<div class='blog__item__pic'>";
                            echo"<img src='img/career.jpg' alt=''>";
                        echo"</div>";
                        echo"<div class='blog__item__text'>";
                            echo"<h5><a href='career.php'>Careers</a></h5>";
                            echo"<p>Want to work with us?</p>";
                        echo"</div>";
                    echo"</div>";
                echo"</div>";
                echo"<div class='col-lg-4 col-md-4 col-sm-6'>";
                    echo"<div class='blog__item'>";
                        echo"<div class='blog__item__pic'>";
                            echo"<img src='img/contact.jpg' alt=''>";
                        echo"</div>";
                        echo"<div class='blog__item__text'>";
                            echo"<h5><a href='contact.php'>Contact us</a></h5>";
                            echo"<p>Feel free to contact us </p>";
                        echo"</div>";
                    echo"</div>";
                echo"</div>";
            echo"</div>";
        echo"</div>";
    echo"</section>";

	//Footer
	include("footer.php");

    echo"<script src='js/jquery-3.3.1.min.js'></script>";
    echo"<script src='js/bootstrap.min.js'></script>";
    echo"<script src='js/jquery.nice-select.min.js'></script>";
    echo"<script src='js/jquery-ui.min.js'></script>";
    echo"<script src='js/jquery.slicknav.js'></script>";
    echo"<script src='js/mixitup.min.js'></script>";
    echo"<script src='js/owl.carousel.min.js'></script>";
    echo"<script src='js/main.js'></script>";


?>
</body>

</html>