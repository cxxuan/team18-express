<?php
	echo "<footer class='footer spad'>";
		echo "<div class='container'>";
			echo "<div class='row'>";
				echo "<div class='col-lg-1 col-md-1'>";
				echo "</div>";
				echo "<div class='col-lg-5 col-md-5'>";
					echo "<div class='footer__about'>";
						echo "<div class='footer__about__logo'>";
							echo "<a href='home.php'><img src='img/Team18_Express_Logo.png' alt='Team18 Express Logo'></a>"; //Logo
						echo "</div>";
						echo "<ul>";
							echo "<li>Email: team18express@gmail.com</li>"; //Email
							echo "<li>Phone: 04-1234567</li>"; //Phone number
							echo "<li>Address: 88, Express Road, 11900 Penang</li>"; //Address
						echo "</ul>";
					echo "</div>";
				echo "</div>";
				echo "<div class='col-lg-3 col-md-3'>";
					echo "<div class='footer__widget'>";
						echo "<h6>USEFUL LINKS</h6>"; //Useful links
						echo "<ul>";
							echo "<li><a href='about.php'>About Us</a></li>"; //Go to About Us page
							echo "<li><a href='contact.php'>Contact Us</a></li>"; //Go to Contact Us page
							echo "<li><a href='career.php'>Careers</a></li>"; //Go to Careers page
							echo "<li><a href='regional_settings.php'>Regional Settings</a></li>"; //Go to Regional Settings page
						echo "</ul>";
					echo "</div>";					
				echo "</div>";
				echo "<div class='col-lg-2 col-md-2'>";
					echo "<div class='footer__widget'>";
						echo "<div class='footer__widget__social'>";
							echo "<h6>VISIT US AT</h6><br/>";
							echo "<a href='https://www.facebook.com/'><i class='fa fa-facebook'></i></a>"; //Facebook
							echo "<a href='https://twitter.com/'><i class='fa fa-twitter'></i></a>"; //Twitter
							echo "<a href='https://www.linkedin.com/'><i class='fa fa-linkedin'></i></a>"; //LinkedIn
						echo "</div>";
					echo "</div>";
				echo "</div>";
				echo "<div class='col-lg-1 col-md-1'>";
				echo "</div>";
			echo "</div>";
			echo "<div class='row'>";
				echo "<div class='col-lg-6 col-md-6'>";
					echo "<div class='footer__copyright'>";
						echo "<div class='footer__copyright__text'>";
							echo "<p>Copyright &copy;2020 Team18 Express. All Rights Reserved.</p>";
						echo "</div>";						
					echo "</div>";
				echo "</div>";
				echo "<div class='col-lg-2 col-md-2'>";
				echo "</div>";
				echo "<div class='col-lg-4 col-md-4'>";
					echo "<div class='footer__copyright'>";
						echo "<div class='footer__copyright__text'>";
							echo "<p>Code of Coduct - Privacy Policy - Terms of Service</p>";
						echo "</div>";						
					echo "</div>";
				echo "</div>";
			echo "</div>";
		echo "</div>";
	echo "</footer>";		
?>	