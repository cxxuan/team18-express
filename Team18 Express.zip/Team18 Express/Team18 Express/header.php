<?php
	//Page Preloder
    echo "<div id='preloder'>";
        echo "<div class='loader'></div>";
    echo "</div>";
	
	echo "<header class='header'>";		
		//Header top
		echo "<div class='header_top'>";
            echo "<div class='container'>";
                echo "<div class='row'>";
					echo "<div class='col-lg-5 col-md-5'>";
                        echo "<div class='header__top__left'>";
                            echo "<ul>";
                                echo "<li><i class='fa fa-envelope'></i>team18express@gmail.com</li>"; //Email
                                echo "<li><i class='fa fa-phone'></i>04-1234567</li>";	//Phone number							
                            echo "</ul>";
                        echo "</div>";
                    echo "</div>";
                    echo "<div class='col-lg-3 col-md-3'>";
                        echo "<div class='header__top__left'>";
                            echo "<div class='header__top__right__auth'>";
								echo "<ul>";
										if (!isset($_SESSION)) {
											session_start();
										} //Start the session
										if(isset($_SESSION['id'])){
											echo "<li><a href='home.php?sign_out=true'><i class='fa fa-user'></i>Sign Out</a></li>"; //Sign Out
										}
										else{
											echo "<li><a href='sign_in.php'><i class='fa fa-user'></i>Sign In</a></li>"; //Go to Sign In page
										}
									echo "<li><a href='signup.php'><i class='fa fa-user'></i>Register</a></li>"; //Go to Register page							
								echo "</ul>";
                            echo "</div>";													
                        echo "</div>";
                    echo "</div>";										
					
					echo "<div class='col-lg-4 col-md-4'>";
						echo "<div class='header__top__right'>";														
							
							//Cookies
							//if cookies are not set by the user
							if (!isset($_COOKIE['country'])) {
								$country = 'Malaysia';
							}
							//if cookies are set by the user
							else {
								$country = $_COOKIE['country'];
							}
							
							//if cookies are not set by the user
							if (!isset($_COOKIE['language'])) {
								$language = 'English';
							}
							//if cookies are set by the user
							else {
								$language = $_COOKIE['language'];
							}
							
							//if cookies are not set by the user
							if (!isset($_COOKIE['currency'])) {
								$currency = 'MYR';
							}
							//if cookies are set by the user
							else {
								$currency = $_COOKIE['currency'];
							}
							
							echo "<div class='header__top__left'>";
								//Display all the settings chosen on top right							
								echo "<ul>";
									echo "<li>$country</li>"; 
									echo "<li>$language</li>";
									echo "<li>$currency</li>";
								echo "</ul>";
							echo "</div>";																																			
							
						echo "</div>";
					echo "</div>";
					
					echo "<div class='col-lg-6 col-md-6'>";
					echo "</div>";
					
					echo "<div class='col-lg-6 col-md-6'>";
						echo "<div class='header__top__right'>";
							
							//Session
							
							//If the user has signed in
							if (isset($_SESSION['id'])) {
								$id = $_SESSION['id'];
								$time = $_SESSION['time'];
								
								date_default_timezone_set('Asia/Kuala_Lumpur');
								
								echo "<p>Welcome, <b>$id</b>! You have logged in since <b>" . date('g:i a', $time) . "</b></p>";
								
								//When sign out action is submitted
								if(isset($_GET['sign_out'])){
									session_destroy(); //Destroy the session
									header('Location: home.php'); //Redirect user to Home page
									exit();
								}
							}
							
						echo "</div>";		
					echo "</div>";		
					
                echo "</div>";
            echo "</div>";
        echo "</div>";		
		
		//Header bottom
		echo "<div class='header_bottom' style='background-color: #EAECEE;'>";
			echo "<div class='container'>";
				echo "<div class='row'>";
					echo "<div class='col-lg-3 col-md-3'>";
						echo "<div class='header__logo'>";
							echo "<a href='home.php'><img src='img/Team18_Express_Logo.png' alt='Team18 Express Logo'></a>"; //Logo
						echo "</div>";
					echo "</div>";
					echo "<div class='col-lg-7 col-md-7'>";
						echo "<nav class='header__menu'>";
							echo "<ul>";
								echo "<br/><li><a href='home.php'>Home</a></li>"; //Go to Home page
								echo "<li><a href='booking.php'>Reservations</a></li>"; //Go to Reservations page
								echo "<li><a href='chooseDate.php'>Destinations</a></li>"; //Go to Destinations page
								echo "<li><a href='career.php'>Careers</a></li><br>"; //Go to Careers page
								echo "<li><a href='about.php'>About Us</a></li>"; //Go to About Us page
								echo "<li><a href='contact.php'>Contact Us</a></li>"; //Go to Contact Us page								
								echo "<li><a href='regional_settings.php'>Regional Settings</a></li>"; //Go to Regional Settings page
							echo "</ul>";
						echo "</nav>";
					echo "</div>";										
				echo "</div>";
			echo "</div>";
		echo "</div>";
    echo "</header>";
?>	