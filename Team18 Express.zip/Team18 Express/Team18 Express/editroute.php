<!DOCTYPE html>
<html lang="zxx">

<head>
    <meta charset="UTF-8">
    <meta name="description" content="Ogani Template">
    <meta name="keywords" content="Ogani, unica, creative, html">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Edit Route</title>    

    <!-- Css Styles -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
	<link rel="stylesheet" href="css/admin.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
		<?php
		if(isset($_POST['submitted'])){
			$valid=true;
			
			$route_id=$_POST['route_id'];
			$route_name=$_POST['route_name'];
			$departure=$_POST['departure'];
			$destination=$_POST['destination'];
			$weekday=$_POST['weekday'];
			$departure_time=$_POST['departure_time'];
			$duration=$_POST['duration'];
				
			$bus_id=$_POST['bus_id'];
			
			$route_name_error="";
			$departure_error="";
			$destination_error="";
			$weekday_error="";
			$departure_time_error="";
			$duration_error="";
			
			if(empty($bus_id)){
				$bus_id_error="<font color='red'>The bus name field should not be empty</font><br/>";
				$valid=false;
			}
			
			if(empty($route_name)){
				$route_name_error="<font color='red'>The route name field should not be empty</font><br/>";
				$valid=false;
			}		
			
			if(empty($departure)){
				$departure_error="<font color='red'>The departure field should not be empty</font><br/>";
				$valid=false;
			}
			
			if(empty($destination)){
				$destination_error="<font color='red'>The destination field should not be empty</font><br/>";
				$valid=false;
			}

			if(empty($weekday)){
				$weekday_error="<font color='red'>The weekday field should not be empty</font><br/>";
				$valid=false;
			}
			
			if(empty($departure_time)){
				$departure_time_error="<font color='red'>The departure time field should not be empty</font><br/>";
				$valid=false;
			}
				
			if(empty($duration)){
				$duration_error="<font color='red'>The duration field should not be empty</font><br/>";
				$valid=false;
			}
			else if(!is_numeric($duration)){
				$duration_error="<font color='red'>The duration field should only be filled in with numbers</font><br/>";
				$valid=false;
			}
			
			if($valid==true){
				$dbc = mysqli_connect('localhost','root','');
				if(mysqli_select_db($dbc,'team18_express')){
					$result="UPDATE route SET route_name = '$route_name', departure = '$departure',
					destination = '$destination', weekday='$weekday', departure_time = '$departure_time',
					duration='$duration',bus_id = '$bus_id' WHERE route.route_id = $route_id";
					
					if(mysqli_query($dbc,$result)){
						mysqli_close($dbc);
						header("Location: admincontrolpanel.php"); 
						exit();
					}
					else{
						print"Error encountered! Redirecting back in 5 seconds...";
							mysqli_close($dbc);
							header("Refresh:5; url=editroute.php");
							exit();
					}
				}	
			}
			else{
				editFormNew($route_id,$bus_id_error,$route_name_error,$departure_error,$destination_error,$weekday_error,$departure_time_error,$duration_error);
			}
			
		}
		
		else{
			$id=$_GET['id'];
			editForm($id);
		}
		?>	
    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>

</body>
</html>

<?php
	function editForm($id){
			$dbc = mysqli_connect('localhost','root','');
			@mysqli_select_db($dbc,'team18_express');
			if($dbc){
				$result=mysqli_query($dbc,"SELECT r.route_name,r.departure,r.destination,r.weekday,r.departure_time,r.duration,b.bus_name
							FROM route r
							JOIN bus b 
							ON (r.bus_id=b.bus_id)
							WHERE r.route_id = $id");
					
					$row=mysqli_fetch_row($result);
					
					include("header.php");
					
					/* Breadcrumb Section Begin */
					echo "<section class='breadcrumb-section set-bg' data-setbg='img/header.jpg'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12 text-center'>";
					echo "				<div class='breadcrumb__text'>";
					echo "					<h2>Edit Route</h2>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</section>";
					/* Breadcrumb Section End */
					
					echo "<div class='admin spad'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12'>";
					echo "				<div class='admin__form'>";
					echo "					<h4>Route Details</h4>";
					echo "					<table width='80%' class='table table-bordered'>";
					echo "						<tr>";
					echo "							<th>Bus name</th>";
					echo "							<td>".$row[5]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Route name</th>";
					echo "							<td>".$row[0]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Departure</th>";
					echo "							<td>".$row[1]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Destination</th>";
					echo "							<td>".$row[2]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Weekday</th>";
					echo "							<td>".$row[3]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Departure time</th>";
					echo "							<td>".$row[4]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Travel duration</th>";
					echo "							<td>".$row[5]."</td>";
					echo "						</tr>";
					echo "					</table>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</div>";
					
					$result=mysqli_query($dbc,"SELECT bus_id,bus_name FROM bus");
					
					echo "<div class='admin spad'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12'>";
					echo "				<div class='admin__form'>";
					echo "					<h4>Edit Details</h4>";
					echo "					<form method='post' action='editroute.php'>";
					echo "						<div class='admin__input'>";
					echo "							<p>Bus name:</p>";
					echo "							<select name='bus_id'>";
					echo "								<option value=''>Choose</option>";
														while($row=mysqli_fetch_array($result)){
															$i=$row['bus_id'];
															print"<option value='$i'>".$row['bus_name']."</option>";
														}
					echo "							</select>";
					echo "						</div>";
					echo "						<br /><br /><br />";
					echo "						<div class='admin__input'>";
					echo "							<p>Route name:</p>";
					echo "							<input name='route_name' type='text' size='30' placeholder='Enter route name'/>";
					echo "						</div>";
					echo "						<div class='admin__input'>";
					echo "							<p>Departure:</p>";
					echo "							<input name='departure' type='text' size='30' placeholder='Enter departure'/>";
					echo "						</div>";
					echo "						<div class='admin__input'>";
					echo "							<p>Destination:</p>";
					echo "							<input name='destination' type='text' size='30' placeholder='Enter destination'/>";
					echo "						</div>";
					echo "						<div class='admin__input'>";
					echo "							<br><p>Week day:</p>";
					echo "							<select name='weekday'>";
					echo "								<option value='Monday'>Monday</option>";
					echo "								<option value='Tuesday'>Tuesday</option>";
					echo "								<option value='Wednesday'>Wednesday</option>";
					echo "								<option value='Thursday'>Thursday</option>";
					echo "								<option value='Friday'>Friday</option>";
					echo "								<option value='Saturday'>Saturday</option>";
					echo "								<option value='Sunday'>Sunday</option>";
					echo "							</select>";
					echo "						</div>";
					echo "						<br/><br/><br/>";
					echo "						<div class='admin__input'>";
					echo "							<p>Departure time:</p>";
					echo "							<input name='departure_time' type='text' size='30' placeholder='Enter departure time'/>";
					echo "						</div>";
					echo "						<div class='admin__input'>";
					echo "							<p>Duration (minutes):</p>";
					echo "							<input name='duration' type='number' size='5' placeholder='Enter duration'/>";
					echo "						</div>";
					echo "						<a href='admincontrolpanel.php'><button class='admin-btn' type='button'>Back</button></a>";
					echo "						<button class='admin-btn' type='submit'>Submit</button>";
					echo "						<input type='hidden' name='submitted' value='true'/>";
					echo "						<input type='hidden' name='route_id' value='$id'/>";
					echo "					</form>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</div>";
					
					include("footer.php");
			}
			else{
					include("header.php");
					
					/* Breadcrumb Section Begin */
					echo "<section class='breadcrumb-section set-bg' data-setbg='img/header.jpg'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12 text-center'>";
					echo "				<div class='breadcrumb__text'>";
					echo "					<h2>Edit Route</h2>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</section>";
					/* Breadcrumb Section End */
					
					echo"<center><p>Failed to fetch data!</p></center>";
					
					include("footer.php");
				}
			mysqli_close($dbc);
	}
	
	function editFormNew($id,$bus_id_error,$route_name_error,$departure_error,$destination_error,$weekday_error,$departure_time_error,$duration_error){
			$dbc = mysqli_connect('localhost','root','');
			@mysqli_select_db($dbc,'team18_express');
			if($dbc){
				$result=mysqli_query($dbc,"SELECT r.route_name,r.departure,r.destination,r.weekday,r.departure_time,r.duration,b.bus_name
							FROM route r
							JOIN bus b 
							ON (r.bus_id=b.bus_id)
							WHERE r.route_id = $id");
					
					$row=mysqli_fetch_row($result);
					
					include("header.php");
					
					/* Breadcrumb Section Begin */
					echo "<section class='breadcrumb-section set-bg' data-setbg='img/header.jpg'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12 text-center'>";
					echo "				<div class='breadcrumb__text'>";
					echo "					<h2>Edit Route</h2>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</section>";
					/* Breadcrumb Section End */
					
					echo "<div class='admin spad'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12'>";
					echo "				<div class='admin__form'>";
					echo "					<h4>Route Details</h4>";
					echo "					<table width='80%' class='table table-bordered'>";
					echo "						<tr>";
					echo "							<th>Bus name</th>";
					echo "							<td>".$row[5]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Route name</th>";
					echo "							<td>".$row[0]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Departure</th>";
					echo "							<td>".$row[1]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Destination</th>";
					echo "							<td>".$row[2]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Weekday</th>";
					echo "							<td>".$row[3]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Departure time</th>";
					echo "							<td>".$row[4]."</td>";
					echo "						</tr>";
					echo "						<tr>";
					echo "							<th>Travel duration</th>";
					echo "							<td>".$row[5]."</td>";
					echo "						</tr>";
					echo "					</table>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</div>";
					
					$result=mysqli_query($dbc,"SELECT bus_id,bus_name FROM bus");
					
					echo "<div class='admin spad'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12'>";
					echo "				<div class='admin__form'>";
					echo "					<h4>Edit Details</h4>";
					echo "					<form method='post' action='editroute.php'>";
					echo "						<div class='admin__input'>";
					echo "							<p>Bus name:</p>";
					echo "							<select name='bus_id'>";
					echo "								<option value=''>Choose</option>";
														while($row=mysqli_fetch_array($result)){
															$i=$row['bus_id'];
															print"<option value='$i'>".$row['bus_name']."</option>";
														}
					echo "							</select>";
					echo "						<br/><br/><font color='red'>*$bus_id_error</font>";
					echo "						</div>";
					echo "						<br />";
					echo "						<div class='admin__input'>";
					echo "							<p>Route name:</p>";
					echo "							<input name='route_name' type='text' size='30' placeholder='Enter route name'/>";
					echo "							<br/><font color='red'>*$route_name_error</font>";
					echo "						</div>";
					echo "						<div class='admin__input'>";
					echo "							<p>Departure:</p>";
					echo "							<input name='departure' type='text' size='30' placeholder='Enter departure'/>";
					echo "							<br/><font color='red'>*$departure_error</font>";
					echo "						</div>";
					echo "						<div class='admin__input'>";
					echo "							<p>Destination:</p>";
					echo "							<input name='destination' type='text' size='30' placeholder='Enter destination'/>";
					echo "							<br/><font color='red'>*$destination_error</font>";
					echo "						</div>";
					echo "						<div class='admin__input'>";
					echo "							<br><p>Week day:</p>";
					echo "							<select name='weekday'>";
					echo "								<option value='Monday'>Monday</option>";
					echo "								<option value='Tuesday'>Tuesday</option>";
					echo "								<option value='Wednesday'>Wednesday</option>";
					echo "								<option value='Thursday'>Thursday</option>";
					echo "								<option value='Friday'>Friday</option>";
					echo "								<option value='Saturday'>Saturday</option>";
					echo "								<option value='Sunday'>Sunday</option>";
					echo "							</select>";
					echo "							<br/><br/><font color='red'>$weekday_error</font>";
					echo "						</div>";
					echo "						<br/>";
					echo "						<div class='admin__input'>";
					echo "							<p>Departure time:</p>";
					echo "							<input name='departure_time' type='text' size='30' placeholder='Enter departure time'/>";
					echo "							<br/><font color='red'>*$departure_time_error</font>";
					echo "						</div>";
					echo "						<div class='admin__input'>";
					echo "							<p>Duration (minutes):</p>";
					echo "							<input name='duration' type='number' size='5' placeholder='Enter duration'/>";
					echo "							<br/><font color='red'>*$duration_error</font>";
					echo "						</div>";
					echo "						<a href='admincontrolpanel.php'><button class='admin-btn' type='button'>Back</button></a>";
					echo "						<button class='admin-btn' type='submit'>Submit</button>";
					echo "						<input type='hidden' name='submitted' value='true'/>";
					echo "						<input type='hidden' name='route_id' value='$id'/>";
					echo "					</form>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</div>";
					
					include("footer.php");
			}
			else{
					include("header.php");
					
					/* Breadcrumb Section Begin */
					echo "<section class='breadcrumb-section set-bg' data-setbg='img/header.jpg'>";
					echo "	<div class='container'>";
					echo "		<div class='row'>";
					echo "			<div class='col-lg-12 text-center'>";
					echo "				<div class='breadcrumb__text'>";
					echo "					<h2>Edit Route</h2>";
					echo "				</div>";
					echo "			</div>";
					echo "		</div>";
					echo "	</div>";
					echo "</section>";
					/* Breadcrumb Section End */
					
					echo"<center><p>Failed to fetch data!</p></center>";
					
					include("footer.php");
				}
			mysqli_close($dbc);
	}
?>