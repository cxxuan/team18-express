<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
    <title>Regional Settings</title>		
	
    <!-- CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css" type="text/css">
    <link rel="stylesheet" href="css/font-awesome.min.css" type="text/css">
    <link rel="stylesheet" href="css/elegant-icons.css" type="text/css">
    <link rel="stylesheet" href="css/nice-select.css" type="text/css">
    <link rel="stylesheet" href="css/jquery-ui.min.css" type="text/css">
    <link rel="stylesheet" href="css/owl.carousel.min.css" type="text/css">
    <link rel="stylesheet" href="css/slicknav.min.css" type="text/css">
    <link rel="stylesheet" href="css/style.css" type="text/css">
</head>

<?php
	include ('cookies_bgcolor.php'); //Cookies background color
?>

<body style="background-color:<?php echo "$background_color"; ?>">
<?php
    //Header Section Begins
    include ('header.php');
    //Header Section Ends	    
	
	//Regional Settings Section Begins
    echo "<section class='breadcrumb-section set-bg' data-setbg='img/about-us1.jpg'>";
        echo "<div class='container'>";
            echo "<div class='row'>";
                echo "<div class='col-lg-12 text-center'>";
                    echo "<div class='breadcrumb__text'>";
                        echo "<br><br><br><br><h2 style='color:white; font-size:80px'>Regional Settings</h2><br>";
						echo "<h5 style='color: white'>Set your preferences when browsing through our website!</h5><br><br><br><br><br>";
                    echo "</div>";
                echo "</div>";
            echo "</div>";
        echo "</div>";
    echo "</section>";
    //Regional Settings Section Ends
	
	//Regional Settings Begins
	echo "<div class='contact-form spad' align='center'>";
        echo "<div class='container'>";
            echo "<div class='row'>";
                echo "<div class='col-lg-12'>";
                    echo "<div class='section-title'>";
                        echo "<h2>Regional Settings</h2>";
                    echo "</div>";
                echo "</div>";
            echo "</div>";						
			
			//Check whether variable is set or declared
			if (isset($_POST['submitted'])) {
				//Save settings in cookies
				setcookie('country', $_POST['country']);
				setcookie('language', $_POST['language']);
				setcookie('currency', $_POST['currency']);
				setcookie('background_color', $_POST['background_color']);

				echo "<p style='font-size: 20px'><b>Successful!</b></p>";
			}
			//Display dropdowns
			else {
				echo "<form method='post' action='regional_settings.php'>";
					echo "<div class='row'>";
						echo "<div class='col-lg-2 col-md-2'>";
						echo "</div>";
						//Country
						echo "<div class='col-lg-2 col-md-2'>";
							echo "<br/><select name ='country'>";
								echo "<option value=''>Country</option>";
								echo "<option value='Malaysia'>Malaysia</option>";
								echo "<option value='Singapore'>Singapore</option>";
								echo "<option value='Indonesia'>Indonesia</option>";
								echo "<option value='Thailand'>Thailand</option>";
								echo "<option value='Vietnam'>Vietnam</option>";
							echo "</select><br/><br/><br/><br/><br/>";
						echo "</div>";
						//Language
						echo "<div class='col-lg-2 col-md-2'>";
							echo "<br/><select name ='language'>";
								echo "<option value=''>Language</option>";
								echo "<option value='English'>English</option>";
								echo "<option value='Mandarin'>Mandarin</option>";
								echo "<option value='Malay'>Malay</option>";
								echo "<option value='Tamil'>Tamil</option>";
								echo "<option value='German'>German</option>";
							echo "</select><br/><br/><br/><br/><br/>";
						echo "</div>";
						//Currency
						echo "<div class='col-lg-2 col-md-2'>";
							echo "<br/><select name ='currency'>";
								echo "<option value=''>Currency</option>";
								echo "<option value='MYR'>MYR</option>";
								echo "<option value='SGD'>SGD</option>";
								echo "<option value='USD'>USD</option>";
								echo "<option value='EUR'>EUR</option>";
								echo "<option value='JPY'>JPY</option>";
							echo "</select><br/><br/><br/><br/><br/>";
						echo "</div>";
						//Background color
						echo "<div class='col-lg-2 col-md-2'>";
							echo "<br/><select name ='background_color'>";
								echo "<option value=''>Background Color</option>";
								echo "<option value='White'>White</option>";
								echo "<option value='Grey'>Grey</option>";
								echo "<option value='Red'>Red</option>";
								echo "<option value='Yellow'>Yellow</option>";
								echo "<option value='Blue'>Blue</option>";
								echo "<option value='Green'>Green</option>";
							echo "</select><br/><br/><br/><br/><br/>";
						echo "</div>";
						echo "<div class='col-lg-2 col-md-2'>";
						echo "</div>";
						echo "<div class='col-lg-12 text-center'>";
							echo "<input type='hidden' name='submitted' value='true'/>";
							echo "<button type='submit' class='site-btn'>SET MY PREFERENCES</button>"; //Submit
						echo "</div>";					
					echo "</div>";
				echo "</form>";
			}
			
        echo "</div>";
    echo "</div>";
	//Regional Settings Ends
	
	//Footer Section Begins
    include ('footer.php');
    //Footer Section Ends
?>

    <!-- Js Plugins -->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/jquery-ui.min.js"></script>
    <script src="js/jquery.slicknav.js"></script>
    <script src="js/mixitup.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/main.js"></script>
	
</body>

</html>